# Zenvix — HOW TO RUN

## Step 1 — Make sure Node.js is installed

Open a terminal and run:
```
node --version
```
You need **v18 or higher**. If you don't have it, download from: https://nodejs.org

---

## Step 2 — Open this folder in VS Code

1. Open VS Code
2. Click **File → Open Folder**
3. Select the **zenvix** folder
4. Open the built-in terminal: **Terminal → New Terminal**

---

## Step 3 — Install dependencies (run ONCE)

In the VS Code terminal, type:
```
npm install
```
Wait for it to finish (30–60 seconds). This creates the `node_modules` folder.

---

## Step 4 — Start the app

```
npm run dev
```

You will see:
```
VITE ready in 400ms
➜  Local: http://localhost:5173/
```

Open your browser and go to: **http://localhost:5173**

---

## Step 5 — Log in with demo accounts

On the Login page, click one of the **Quick Demo** buttons:

| Button         | What you get                          |
|----------------|---------------------------------------|
| Student Demo   | Full learning dashboard               |
| Employer Demo  | Job posting + applicant review        |
| Admin Demo     | Platform analytics + user management  |

Then click **Log In**.

---

## Troubleshooting

**"npm: command not found"**
→ Install Node.js from https://nodejs.org (choose LTS version)

**"Cannot find module" errors**
→ Run `npm install` again

**Port already in use**
→ Vite will automatically try port 5174, 5175, etc. Check the terminal output.

**Blank white screen**
→ Open browser DevTools (F12), check the Console tab for errors, paste them here.

**Tailwind styles not showing (plain HTML)**
→ Make sure you ran `npm install` and are using `npm run dev`, not opening index.html directly.

