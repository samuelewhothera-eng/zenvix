@echo off
echo.
echo  ============================================
echo   Zenvix - Starting up...
echo  ============================================
echo.

:: Check if node_modules exists
IF NOT EXIST "node_modules\" (
    echo  Installing dependencies for the first time...
    echo  This will take about 1 minute. Please wait.
    echo.
    call npm install
    echo.
)

echo  Starting Zenvix...
echo  Open your browser at: http://localhost:5173
echo.
call npm run dev
