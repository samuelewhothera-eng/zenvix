/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        display: ["'Syne'", "sans-serif"],
        body: ["'DM Sans'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      colors: {
        brand: { 50:"#f0f9ff",100:"#e0f2fe",200:"#bae6fd",300:"#7dd3fc",400:"#38bdf8",500:"#0ea5e9",600:"#0284c7",700:"#0369a1",800:"#075985",900:"#0c4a6e" },
        accent: { 400:"#e879f9",500:"#d946ef",600:"#c026d3" },
      },
      animation: {
        "fade-in": "fadeIn 0.5s ease-out forwards",
        "slide-up": "slideUp 0.6s cubic-bezier(0.16,1,0.3,1) forwards",
        float: "float 6s ease-in-out infinite",
        shimmer: "shimmer 2s linear infinite",
        glow: "glow 2s ease-in-out infinite alternate",
      },
      keyframes: {
        fadeIn: { "0%":{opacity:"0"},"100%":{opacity:"1"} },
        slideUp: { "0%":{opacity:"0",transform:"translateY(24px)"},"100%":{opacity:"1",transform:"translateY(0)"} },
        float: { "0%,100%":{transform:"translateY(0px)"},"50%":{transform:"translateY(-20px)"} },
        shimmer: { "0%":{backgroundPosition:"-200% 0"},"100%":{backgroundPosition:"200% 0"} },
        glow: { "0%":{boxShadow:"0 0 20px rgba(14,165,233,0.3)"},"100%":{boxShadow:"0 0 40px rgba(14,165,233,0.7)"} },
      },
      boxShadow: {
        card: "0 1px 3px 0 rgba(0,0,0,.06),0 8px 24px -4px rgba(0,0,0,.08)",
        "card-hover": "0 4px 12px 0 rgba(0,0,0,.08),0 24px 48px -8px rgba(0,0,0,.12)",
        glow: "0 0 30px rgba(14,165,233,0.35)",
      },
    },
  },
  plugins: [],
};
