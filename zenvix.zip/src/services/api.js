// services/api.js
// API service layer - all functions simulate real API calls
// Replace the mock data with real Axios calls when backend is ready
// Pattern: all functions return { data, error } for consistent error handling

import axios from "axios";
import * as mock from "../data/mockData";

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

// Axios instance (used when backend is connected)
export const api = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" },
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("zv-token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Global response interceptor
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem("zv-token");
      localStorage.removeItem("sb-role");
      window.location.href = "/login";
    }
    return Promise.reject(err);
  }
);

// Simulate network delay for realistic UX
const delay = (ms = 600) => new Promise(r => setTimeout(r, ms));

// ==================== AUTH ====================
export const authService = {
  async login(email, password) {
    await delay(800);
    return { data: { user: mock.mockUser, token: "mock_jwt_token_xxx" }, error: null };
  },
  async register(data) {
    await delay(1000);
    return { data: { user: mock.mockUser, token: "mock_jwt_token_xxx" }, error: null };
  },
  async forgotPassword(email) {
    await delay(600);
    return { data: { message: "Reset email sent" }, error: null };
  },
};

// ==================== COURSES ====================
export const courseService = {
  async getAll(filters = {}) {
    await delay(500);
    let courses = [...mock.mockCourses];
    if (filters.category && filters.category !== "All") {
      courses = courses.filter(c => c.category === filters.category);
    }
    if (filters.level && filters.level !== "All Levels") {
      courses = courses.filter(c => c.level === filters.level);
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      courses = courses.filter(c => c.title.toLowerCase().includes(q) || c.tags.some(t => t.toLowerCase().includes(q)));
    }
    return { data: courses, error: null };
  },
  async getById(id) {
    await delay(400);
    const course = mock.mockCourses.find(c => c.id === id);
    return { data: course || null, error: course ? null : "Not found" };
  },
  async enroll(courseId) {
    await delay(600);
    return { data: { success: true }, error: null };
  },
  async updateProgress(courseId, lessonId) {
    await delay(300);
    return { data: { success: true }, error: null };
  },
};

// ==================== JOBS ====================
export const jobService = {
  async getAll(filters = {}) {
    await delay(500);
    let jobs = [...mock.mockJobs];
    if (filters.category && filters.category !== "All") {
      jobs = jobs.filter(j => j.category === filters.category);
    }
    if (filters.type && filters.type !== "All Types") {
      jobs = jobs.filter(j => j.type === filters.type);
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      jobs = jobs.filter(j => j.title.toLowerCase().includes(q) || j.company.toLowerCase().includes(q));
    }
    return { data: jobs, error: null };
  },
  async getById(id) {
    await delay(400);
    const job = mock.mockJobs.find(j => j.id === id);
    return { data: job || null, error: null };
  },
  async apply(jobId) {
    await delay(700);
    return { data: { success: true, applicationId: "app_" + Date.now() }, error: null };
  },
};

// ==================== CERTIFICATES ====================
export const certificateService = {
  async getAll() {
    await delay(400);
    return { data: mock.mockCertificates, error: null };
  },
  async getById(id) {
    await delay(300);
    const cert = mock.mockCertificates.find(c => c.id === id);
    return { data: cert || null, error: null };
  },
  async verify(verificationId) {
    await delay(500);
    const cert = mock.mockCertificates.find(c => c.verificationId === verificationId);
    return { data: cert || null, error: cert ? null : "Certificate not found" };
  },
};

// ==================== AI ASSISTANT ====================
export const aiService = {
  async chat(messages) {
    await delay(1200);
    const responses = [
      "Great question! For React interview prep, focus on: hooks (useState, useEffect, useContext), component lifecycle, and state management patterns. Practice explaining the Virtual DOM and reconciliation algorithm.",
      "Based on your current skills in React and JavaScript, I recommend learning TypeScript next. It will make you significantly more employable and improve your code quality.",
      "Your resume looks strong! I'd suggest quantifying your achievements. Instead of 'built a web app', say 'built a web app serving 200+ daily users with 99% uptime'.",
      "For salary negotiation, research market rates first. In your region, junior frontend roles typically pay $600-$1,400/month remotely. Start by asking for the higher end.",
      "Async/await is syntactic sugar over Promises. It makes asynchronous code read like synchronous code. Think of 'await' as saying 'wait for this to finish before moving on'.",
    ];
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    return { data: { content: randomResponse }, error: null };
  },
};

// ==================== USER ====================
export const userService = {
  async getProfile() {
    await delay(400);
    return { data: mock.mockUser, error: null };
  },
  async updateProfile(data) {
    await delay(600);
    return { data: { ...mock.mockUser, ...data }, error: null };
  },
  async getDashboardData() {
    await delay(500);
    return {
      data: {
        user: mock.mockUser,
        enrolledCourses: mock.mockCourses.filter(c => c.isEnrolled),
        certificates: mock.mockCertificates,
        recentActivity: mock.mockActivities,
        upcomingInterviews: mock.mockInterviews,
        skillData: mock.mockSkillData,
        progressData: mock.mockProgressData,
      },
      error: null,
    };
  },
};
