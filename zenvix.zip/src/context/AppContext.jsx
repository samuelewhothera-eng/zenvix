// AppContext - Central state management for Zenvix
// Uses React Context API (easily swappable to Zustand for larger scale)
import { createContext, useContext, useState, useEffect } from "react";
import { mockUser, mockEmployer } from "../data/mockData";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [theme, setTheme] = useState(() => localStorage.getItem("zv-theme") || "light");
  const [isLoading, setIsLoading] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, text: "You scored 92% on the React quiz!", read: false, time: "2h ago" },
    { id: 2, text: "New job match: Junior Dev at Andela", read: false, time: "1d ago" },
    { id: 3, text: "Certificate ready to download", read: true, time: "3d ago" },
  ]);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("zv-theme", theme);
  }, [theme]);

  // Simulate auto-login from stored session
  useEffect(() => {
    const storedRole = localStorage.getItem("zv-role");
    if (storedRole === "student") setUser(mockUser);
    else if (storedRole === "employer") setUser({ ...mockEmployer, role: "employer" });
    else if (storedRole === "admin") setUser({ ...mockUser, role: "admin", name: "Admin User" });
  }, []);

  const login = async (email, password, role = "student") => {
    setIsLoading(true);
    // Simulate API call delay
    await new Promise(r => setTimeout(r, 1000));
    const userData = role === "employer" ? { ...mockEmployer, role: "employer" } 
                   : role === "admin" ? { ...mockUser, role: "admin", name: "Admin User" }
                   : mockUser;
    setUser(userData);
    localStorage.setItem("zv-role", role);
    setIsLoading(false);
    return userData;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("zv-role");
  };

  const toggleTheme = () => setTheme(t => t === "light" ? "dark" : "light");

  const markAllRead = () => setNotifications(n => n.map(item => ({ ...item, read: true })));

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <AppContext.Provider value={{
      user, setUser, theme, toggleTheme, isLoading,
      login, logout, notifications, markAllRead, unreadCount,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
};
