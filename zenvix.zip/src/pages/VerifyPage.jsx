import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Clock, CheckCircle2, XCircle, Award, ArrowRight, Target, Zap } from "lucide-react";
import { mockQuizQuestions } from "../data/mockData";
import { Card, Badge, ProgressBar, Button } from "../components/ui";
import { clsx } from "clsx";
import toast from "react-hot-toast";

const QUIZ_TIME = 5 * 60; // 5 minutes

const assessments = [
  { id: "react", title: "React Fundamentals", questions: 5, time: "5 min", level: "Intermediate", badge: "⚛️", color: "blue" },
  { id: "js", title: "JavaScript Essentials", questions: 10, time: "10 min", level: "Beginner", badge: "📜", color: "yellow" },
  { id: "css", title: "CSS & Responsive Design", questions: 8, time: "8 min", level: "Beginner", badge: "🎨", color: "purple" },
  { id: "node", title: "Node.js & APIs", questions: 10, time: "10 min", level: "Intermediate", badge: "🟢", color: "green" },
  { id: "git", title: "Git & Version Control", questions: 6, time: "6 min", level: "Beginner", badge: "🌿", color: "orange" },
  { id: "db", title: "Database Design", questions: 8, time: "8 min", level: "Advanced", badge: "🗄️", color: "red" },
];

const levelColors = { Beginner: "green", Intermediate: "orange", Advanced: "red" };

export default function VerifyPage() {
  const [stage, setStage] = useState("select"); // select | quiz | result
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [selected, setSelected] = useState(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [timeLeft, setTimeLeft] = useState(QUIZ_TIME);
  const [score, setScore] = useState(0);
  const timerRef = useRef(null);

  useEffect(() => {
    if (stage === "quiz") {
      timerRef.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) { clearInterval(timerRef.current); finishQuiz(); return 0; }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [stage]);

  const startQuiz = (assessment) => {
    setSelectedAssessment(assessment);
    setCurrent(0);
    setAnswers({});
    setSelected(null);
    setShowExplanation(false);
    setTimeLeft(QUIZ_TIME);
    setStage("quiz");
  };

  const handleAnswer = (optionIdx) => {
    if (selected !== null) return;
    setSelected(optionIdx);
    const correct = mockQuizQuestions[current].correct;
    const newAnswers = { ...answers, [current]: { selected: optionIdx, correct: optionIdx === correct } };
    setAnswers(newAnswers);
    setShowExplanation(true);
  };

  const nextQuestion = () => {
    if (current < mockQuizQuestions.length - 1) {
      setCurrent(c => c + 1);
      setSelected(null);
      setShowExplanation(false);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    clearInterval(timerRef.current);
    const correct = Object.values(answers).filter(a => a.correct).length;
    setScore(Math.round((correct / mockQuizQuestions.length) * 100));
    setStage("result");
  };

  const formatTime = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  const q = mockQuizQuestions[current];
  const correctCount = Object.values(answers).filter(a => a.correct).length;

  // ===== SELECT STAGE =====
  if (stage === "select") return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-3xl font-bold text-[var(--text-primary)] mb-1">Skill Verification</h1>
        <p className="text-[var(--text-secondary)]">Pass an assessment to earn a verified skill badge employers trust</p>
      </div>

      <div className="bg-gradient-to-r from-brand-500/10 to-purple-500/10 border border-brand-500/20 rounded-2xl p-5 flex items-start gap-4">
        <div className="w-10 h-10 bg-brand-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
          <Target size={20} className="text-brand-500" />
        </div>
        <div>
          <h3 className="font-bold text-[var(--text-primary)] mb-1">How Verification Works</h3>
          <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
            Take a timed, proctored assessment. Score 70%+ to earn a verified badge shown on your profile. 
            Employers see these badges and trust your skills are real.
          </p>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {assessments.map(a => (
          <Card key={a.id} hover className="p-5" onClick={() => startQuiz(a)}>
            <div className="text-3xl mb-3">{a.badge}</div>
            <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-1">{a.title}</h3>
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge variant={levelColors[a.level] || "gray"}>{a.level}</Badge>
              <Badge variant="gray"><Clock size={10} /> {a.time}</Badge>
              <Badge variant="blue">{a.questions} questions</Badge>
            </div>
            <button className="btn-primary w-full justify-center text-sm py-2.5 mt-2">
              <Zap size={13} /> Start Assessment
            </button>
          </Card>
        ))}
      </div>
    </div>
  );

  // ===== QUIZ STAGE =====
  if (stage === "quiz") return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-sm text-[var(--text-muted)]">Question {current + 1} of {mockQuizQuestions.length}</p>
          <h2 className="font-display font-bold text-xl text-[var(--text-primary)]">{selectedAssessment?.title}</h2>
        </div>
        <div className={clsx("flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-bold text-base border",
          timeLeft < 60 ? "bg-red-500/10 text-red-500 border-red-500/20" : "bg-[var(--bg-secondary)] text-[var(--text-primary)] border-[var(--border-color)]"
        )}>
          <Clock size={16} />
          {formatTime(timeLeft)}
        </div>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <ProgressBar value={current + 1} max={mockQuizQuestions.length} />
        <div className="flex justify-between text-xs text-[var(--text-muted)] mt-1.5">
          <span>{correctCount} correct so far</span>
          <span>{mockQuizQuestions.length - current - 1} remaining</span>
        </div>
      </div>

      {/* Question Card */}
      <Card className="p-6 mb-4">
        <p className="font-display font-bold text-lg text-[var(--text-primary)] leading-relaxed mb-6">
          {q.question}
        </p>

        <div className="space-y-3">
          {q.options.map((option, idx) => {
            let optClass = "bg-[var(--card-bg)] border border-[var(--border-color)] hover:border-brand-500/50 hover:bg-brand-500/5";
            if (selected !== null) {
              if (idx === q.correct) optClass = "border-emerald-500 bg-emerald-500/10";
              else if (idx === selected && idx !== q.correct) optClass = "border-red-500 bg-red-500/10";
            } else if (selected === idx) {
              optClass = "border-brand-500 bg-brand-500/10";
            }
            return (
              <button
                key={idx}
                onClick={() => handleAnswer(idx)}
                disabled={selected !== null}
                className={clsx("w-full text-left p-4 rounded-xl border-2 transition-all duration-150 flex items-center gap-3", optClass, selected === null && "cursor-pointer")}
              >
                <span className={clsx("w-7 h-7 rounded-full border-2 flex items-center justify-center text-xs font-bold flex-shrink-0",
                  selected !== null && idx === q.correct ? "border-emerald-500 bg-emerald-500 text-white" :
                  selected !== null && idx === selected ? "border-red-500 bg-red-500 text-white" :
                  "border-[var(--border-color)] text-[var(--text-muted)]"
                )}>
                  {selected !== null && idx === q.correct ? <CheckCircle2 size={14} /> :
                   selected !== null && idx === selected && idx !== q.correct ? <XCircle size={14} /> :
                   String.fromCharCode(65 + idx)}
                </span>
                <span className="text-sm font-medium text-[var(--text-primary)]">{option}</span>
              </button>
            );
          })}
        </div>

        {showExplanation && (
          <div className={clsx("mt-4 p-4 rounded-xl text-sm", answers[current]?.correct ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400" : "bg-red-500/10 text-red-700 dark:text-red-400")}>
            <p className="font-semibold mb-1">{answers[current]?.correct ? "✅ Correct!" : "❌ Incorrect"}</p>
            <p>{q.explanation}</p>
          </div>
        )}
      </Card>

      {selected !== null && (
        <Button variant="primary" className="w-full justify-center py-3.5" onClick={nextQuestion}>
          {current < mockQuizQuestions.length - 1 ? <>Next Question <ArrowRight size={16} /></> : "See Results 🎯"}
        </Button>
      )}
    </div>
  );

  // ===== RESULT STAGE =====
  const passed = score >= 70;
  return (
    <div className="max-w-lg mx-auto text-center animate-slide-up">
      <div className={clsx("w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-6 text-5xl shadow-xl", passed ? "bg-gradient-to-br from-emerald-400 to-emerald-600" : "bg-gradient-to-br from-red-400 to-red-600")}>
        {passed ? "🏆" : "😔"}
      </div>

      <h1 className="font-display text-4xl font-bold text-[var(--text-primary)] mb-2">
        {passed ? "You Passed!" : "Not Quite"}
      </h1>
      <p className="text-[var(--text-secondary)] mb-6">
        {passed ? `You've earned the ${selectedAssessment?.title} verified badge!` : "You need 70% to pass. Review and try again!"}
      </p>

      {/* Score display */}
      <Card className="p-6 mb-6">
        <div className="text-6xl font-display font-black mb-2" style={{ color: passed ? "#10b981" : "#ef4444" }}>
          {score}%
        </div>
        <p className="text-[var(--text-secondary)] mb-4">{correctCount}/{mockQuizQuestions.length} questions correct</p>
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-emerald-500/10 rounded-xl p-3">
            <p className="text-2xl font-bold text-emerald-500">{correctCount}</p>
            <p className="text-xs text-[var(--text-muted)]">Correct</p>
          </div>
          <div className="bg-red-500/10 rounded-xl p-3">
            <p className="text-2xl font-bold text-red-500">{mockQuizQuestions.length - correctCount}</p>
            <p className="text-xs text-[var(--text-muted)]">Incorrect</p>
          </div>
          <div className="bg-brand-500/10 rounded-xl p-3">
            <p className="text-2xl font-bold text-brand-500">{formatTime(QUIZ_TIME - timeLeft)}</p>
            <p className="text-xs text-[var(--text-muted)]">Time Taken</p>
          </div>
        </div>
      </Card>

      <div className="flex flex-col gap-3">
        {passed ? (
          <Link to="/certificates" className="btn-primary justify-center py-3.5 text-base">
            <Award size={18} /> View Your Certificate
          </Link>
        ) : (
          <Button variant="primary" className="justify-center py-3.5 text-base" onClick={() => setStage("select")}>
            Try Again
          </Button>
        )}
        <button onClick={() => setStage("select")} className="btn-secondary justify-center">
          Back to Assessments
        </button>
      </div>
    </div>
  );
}
