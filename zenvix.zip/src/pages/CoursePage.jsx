import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Play, CheckCircle2, Lock, BookOpen, Clock, Users, Award, ChevronRight, FileText, HelpCircle, ArrowLeft } from "lucide-react";
import { mockCourses } from "../data/mockData";
import { Badge, StarRating, ProgressBar, Button } from "../components/ui";
import toast from "react-hot-toast";

const levelColors = { Beginner: "green", Intermediate: "orange", Advanced: "red" };

export default function CoursePage() {
  const { id } = useParams();
  const [course, setCourse] = useState(null);
  const [activeLesson, setActiveLesson] = useState(null);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);
  const [enrolled, setEnrolled] = useState(false);
  const [enrolling, setEnrolling] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      const found = mockCourses.find(c => c.id === id) || mockCourses[0];
      setCourse(found);
      setEnrolled(found?.isEnrolled || false);
      setActiveLesson(found?.lessons_list?.[0] || null);
      setLoading(false);
    }, 400);
  }, [id]);

  const handleEnroll = async () => {
    setEnrolling(true);
    await new Promise(r => setTimeout(r, 800));
    setEnrolled(true);
    setEnrolling(false);
    toast.success("Enrolled successfully! 🎉");
  };

  const markComplete = (lessonId) => {
    setCourse(c => ({
      ...c,
      lessons_list: c.lessons_list.map(l => l.id === lessonId ? { ...l, completed: true } : l),
    }));
    toast.success("Lesson marked complete ✅");
  };

  if (loading) return (
    <div className="animate-pulse space-y-4">
      <div className="h-8 bg-[var(--bg-tertiary)] rounded-xl w-1/3" />
      <div className="h-64 bg-[var(--bg-tertiary)] rounded-2xl" />
    </div>
  );

  if (!course) return (
    <div className="text-center py-20">
      <p className="text-[var(--text-secondary)]">Course not found</p>
      <Link to="/courses" className="btn-primary mt-4">Back to Courses</Link>
    </div>
  );

  const completedCount = course.lessons_list?.filter(l => l.completed).length || 0;
  const totalLessons = course.lessons_list?.length || 0;
  const progress = totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : course.progress;

  return (
    <div className="animate-fade-in">
      <Link to="/courses" className="inline-flex items-center gap-2 text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] mb-6 transition-colors">
        <ArrowLeft size={15} /> Back to Courses
      </Link>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-5">
          {/* Video Player Placeholder */}
          <div className="bg-gray-900 rounded-2xl overflow-hidden aspect-video flex items-center justify-center relative group cursor-pointer shadow-2xl">
            {activeLesson ? (
              <>
                <div className="absolute inset-0 bg-gradient-to-br from-brand-900/50 to-purple-900/50" />
                <div className="relative z-10 text-center">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform border border-white/30">
                    <Play size={28} className="text-white ml-1" />
                  </div>
                  <p className="text-white font-display font-bold text-lg">{activeLesson.title}</p>
                  <p className="text-white/60 text-sm mt-1">{activeLesson.duration}</p>
                </div>
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    <span className="text-white/70 text-xs">Click to play lesson</span>
                  </div>
                  {enrolled && !activeLesson.completed && (
                    <button onClick={() => markComplete(activeLesson.id)}
                      className="text-xs bg-emerald-500 text-white px-3 py-1.5 rounded-lg font-semibold hover:bg-emerald-600 transition-colors">
                      Mark Complete
                    </button>
                  )}
                </div>
              </>
            ) : (
              <div className="text-center text-white/50">
                <Play size={40} className="mx-auto mb-2" />
                <p>Select a lesson to start</p>
              </div>
            )}
          </div>

          {/* Course Info */}
          <div>
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge variant={levelColors[course.level] || "gray"}>{course.level}</Badge>
              <Badge variant="blue">{course.category}</Badge>
              {course.isPremium && <Badge variant="orange"><Lock size={10} /> Pro</Badge>}
            </div>
            <h1 className="font-display text-2xl font-bold text-[var(--text-primary)] mb-2">{course.title}</h1>
            <p className="text-[var(--text-secondary)] text-sm leading-relaxed mb-3">{course.description}</p>
            <div className="flex flex-wrap items-center gap-4 text-sm text-[var(--text-secondary)]">
              <StarRating rating={course.rating} reviews={course.reviews} />
              <span className="flex items-center gap-1"><Users size={13} />{course.students.toLocaleString()} students</span>
              <span className="flex items-center gap-1"><Clock size={13} />{course.duration}</span>
              <span className="flex items-center gap-1"><BookOpen size={13} />{course.lessons} lessons</span>
            </div>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {course.tags.map(tag => (
              <span key={tag} className="px-3 py-1 bg-[var(--bg-tertiary)] text-[var(--text-secondary)] text-xs rounded-lg font-medium">
                {tag}
              </span>
            ))}
          </div>

          {/* Progress (if enrolled) */}
          {enrolled && totalLessons > 0 && (
            <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl p-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="font-semibold text-[var(--text-primary)]">Your Progress</span>
                <span className="font-bold text-brand-500">{progress}%</span>
              </div>
              <ProgressBar value={progress} />
              <p className="text-xs text-[var(--text-muted)] mt-2">{completedCount} of {totalLessons} lessons completed</p>
            </div>
          )}

          {/* Notes */}
          {enrolled && (
            <div className="bg-[var(--card-bg)] border border-[var(--border-color)] rounded-2xl p-5">
              <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-3 flex items-center gap-2">
                <FileText size={16} className="text-brand-500" /> My Notes
              </h3>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Take notes as you learn... (auto-saved)"
                className="w-full h-28 px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 resize-none text-sm"
              />
              <div className="flex justify-between items-center mt-2">
                <p className="text-xs text-[var(--text-muted)]">{notes.length} characters</p>
                <button onClick={() => toast.success("Notes saved!")} className="text-xs text-brand-500 hover:text-brand-600 font-semibold">Save Notes</button>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-5">
          {/* Enroll Card */}
          {!enrolled ? (
            <div className="bg-[var(--card-bg)] border border-[var(--border-color)] rounded-2xl p-5 sticky top-24">
              <img src={course.thumbnail} alt={course.title} className="w-full h-36 object-cover rounded-xl mb-4" />
              <div className="text-center mb-4">
                <p className="font-display text-3xl font-bold text-[var(--text-primary)] mb-1">
                  {course.isPremium ? "Pro Plan" : "Free"}
                </p>
                {course.isPremium && <p className="text-sm text-[var(--text-muted)]">$9.99/month for all courses</p>}
              </div>
              <Button variant="primary" className="w-full justify-center py-3" loading={enrolling} onClick={handleEnroll}>
                {course.isPremium ? <><Lock size={14} /> Get Pro Access</> : "Enroll Now — Free"}
              </Button>
              <p className="text-center text-xs text-[var(--text-muted)] mt-3">30-day money-back guarantee</p>
            </div>
          ) : (
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4 text-center">
              <CheckCircle2 size={24} className="text-emerald-500 mx-auto mb-2" />
              <p className="font-semibold text-sm text-emerald-700 dark:text-emerald-400">You're enrolled!</p>
              {progress === 100 && (
                <Link to="/certificates" className="btn-primary text-sm mt-3 justify-center w-full"><Award size={14} /> View Certificate</Link>
              )}
            </div>
          )}

          {/* Lessons List */}
          {totalLessons > 0 && (
            <div className="bg-[var(--card-bg)] border border-[var(--border-color)] rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-[var(--border-color)]">
                <h3 className="font-display font-bold text-base text-[var(--text-primary)]">Course Content</h3>
                <p className="text-xs text-[var(--text-muted)] mt-0.5">{totalLessons} lessons · {course.duration}</p>
              </div>
              <div className="divide-y divide-[var(--border-color)]">
                {course.lessons_list.map((lesson, idx) => {
                  const isActive = activeLesson?.id === lesson.id;
                  const isLocked = !enrolled && idx > 1;
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => !isLocked && setActiveLesson(lesson)}
                      className={`w-full text-left p-4 flex items-center gap-3 transition-colors hover:bg-[var(--bg-secondary)] ${isActive ? "bg-brand-500/5 border-l-2 border-brand-500" : ""} ${isLocked ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                    >
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${lesson.completed ? "bg-emerald-500 text-white" : isActive ? "bg-brand-500 text-white" : "bg-[var(--bg-tertiary)] text-[var(--text-muted)]"}`}>
                        {lesson.completed ? <CheckCircle2 size={14} /> : isLocked ? <Lock size={11} /> : lesson.type === "quiz" ? <HelpCircle size={13} /> : idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm truncate ${isActive ? "font-semibold text-brand-600 dark:text-brand-400" : "text-[var(--text-primary)]"}`}>{lesson.title}</p>
                        <p className="text-xs text-[var(--text-muted)]">{lesson.duration}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Take Quiz Button */}
          {enrolled && (
            <Link to="/verify" className="bg-gradient-to-br from-purple-500 to-brand-500 text-white rounded-2xl p-5 flex items-center gap-3 hover:opacity-90 transition-opacity">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                <HelpCircle size={20} />
              </div>
              <div>
                <p className="font-bold text-sm">Take Skill Assessment</p>
                <p className="text-white/70 text-xs mt-0.5">Earn your verified badge</p>
              </div>
              <ChevronRight size={16} className="ml-auto" />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
