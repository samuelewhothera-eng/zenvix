// Student Dashboard - Complete overview
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { BookOpen, Award, Briefcase, Zap, TrendingUp, Clock, ArrowRight, Calendar, Target, Flame } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis } from "recharts";
import { useApp } from "../context/AppContext";
import { mockCourses, mockCertificates, mockActivities, mockInterviews, mockSkillData, mockProgressData } from "../data/mockData";
import { Card, Badge, ProgressBar, Avatar, StatCard } from "../components/ui";
import { StatCardSkeleton, CourseCardSkeleton } from "../components/skeletons";

const activityIcons = { book: "📚", target: "🎯", award: "🏆", briefcase: "💼" };
const statusColors = { Scheduled: "green", Pending: "orange", Completed: "gray" };

export default function DashboardPage() {
  const { user } = useApp();
  const [loading, setLoading] = useState(true);
  const enrolledCourses = mockCourses.filter(c => c.isEnrolled);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(t);
  }, []);

  const stats = [
    { label: "Courses Enrolled", value: "4", change: 25, icon: BookOpen, color: "blue" },
    { label: "Certificates", value: "3", change: 50, icon: Award, color: "purple" },
    { label: "Total XP", value: "2,840", change: 12, icon: Zap, color: "orange" },
    { label: "Job Applications", value: "2", change: 100, icon: Briefcase, color: "green" },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h1 className="font-display text-2xl md:text-3xl font-bold text-[var(--text-primary)]">
              Good morning, {user?.name?.split(" ")[0]} 👋
            </h1>
            <div className="flex items-center gap-1.5 px-3 py-1 bg-orange-500/10 rounded-full">
              <Flame size={14} className="text-orange-500" />
              <span className="text-xs font-bold text-orange-500">{user?.streak}-day streak</span>
            </div>
          </div>
          <p className="text-[var(--text-secondary)]">You're making great progress! Keep going 💪</p>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/courses" className="btn-secondary text-sm">Browse Courses</Link>
          <Link to="/jobs" className="btn-primary text-sm">Find Jobs</Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {loading ? (
          Array(4).fill(0).map((_, i) => <StatCardSkeleton key={i} />)
        ) : (
          stats.map(s => <StatCard key={s.label} {...s} />)
        )}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Learning Progress (2/3) */}
        <div className="lg:col-span-2 space-y-6">
          {/* XP Chart */}
          <Card className="p-5">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display font-bold text-lg text-[var(--text-primary)]">Weekly XP Progress</h2>
              <Badge variant="blue">Last 7 weeks</Badge>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={mockProgressData}>
                <defs>
                  <linearGradient id="xpGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip contentStyle={{ background: "var(--card-bg)", border: "1px solid var(--border-color)", borderRadius: "12px", fontSize: "12px" }} />
                <Area type="monotone" dataKey="xp" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#xpGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </Card>

          {/* Enrolled Courses */}
          <Card className="p-5">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display font-bold text-lg text-[var(--text-primary)]">Continue Learning</h2>
              <Link to="/courses" className="text-sm text-brand-500 hover:text-brand-600 font-semibold flex items-center gap-1">
                View all <ArrowRight size={14} />
              </Link>
            </div>
            <div className="space-y-4">
              {enrolledCourses.filter(c => c.progress > 0 && c.progress < 100).map(course => (
                <Link key={course.id} to={`/courses/${course.id}`}>
                  <div className="flex items-center gap-4 p-3 rounded-xl hover:bg-[var(--bg-secondary)] transition-colors group">
                    <img src={course.thumbnail} alt={course.title} className="w-14 h-14 rounded-xl object-cover flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-[var(--text-primary)] truncate group-hover:text-brand-500 transition-colors">{course.title}</p>
                      <p className="text-xs text-[var(--text-muted)] mb-2">{course.instructor}</p>
                      <ProgressBar value={course.progress} showLabel />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </Card>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Profile Card */}
          <Card className="p-5">
            <div className="flex flex-col items-center text-center">
              <Avatar src={user?.avatar} name={user?.name} size="xl" className="mb-3" />
              <h3 className="font-display font-bold text-base text-[var(--text-primary)]">{user?.name}</h3>
              <p className="text-sm text-[var(--text-secondary)] mb-3">{user?.title}</p>
              <div className="flex items-center gap-1.5 mb-4">
                <div className="w-5 h-5 bg-brand-500/20 rounded-full flex items-center justify-center">
                  <Zap size={11} className="text-brand-500" />
                </div>
                <span className="text-sm font-bold text-brand-500">Level {user?.level}</span>
                <span className="text-xs text-[var(--text-muted)]">— {user?.xp?.toLocaleString()} XP</span>
              </div>
              {/* XP to next level */}
              <div className="w-full">
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-[var(--text-muted)]">Level {user?.level}</span>
                  <span className="text-[var(--text-muted)]">Level {user?.level + 1}</span>
                </div>
                <ProgressBar value={68} color="brand" />
                <p className="text-xs text-[var(--text-muted)] mt-1.5 text-center">460 XP to next level</p>
              </div>
            </div>
          </Card>

          {/* Skill Radar */}
          <Card className="p-5">
            <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4">Skill Overview</h3>
            <ResponsiveContainer width="100%" height={180}>
              <RadarChart data={mockSkillData}>
                <PolarGrid stroke="var(--border-color)" />
                <PolarAngleAxis dataKey="skill" tick={{ fontSize: 10, fill: "var(--text-muted)" }} />
                <Radar name="Level" dataKey="level" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.2} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
            <Link to="/verify" className="btn-primary w-full justify-center text-sm mt-2">
              <Target size={15} /> Take Skill Assessment
            </Link>
          </Card>

          {/* Upcoming Interviews */}
          <Card className="p-5">
            <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4 flex items-center gap-2">
              <Calendar size={16} className="text-brand-500" /> Upcoming Interviews
            </h3>
            {mockInterviews.length > 0 ? (
              <div className="space-y-3">
                {mockInterviews.map(int => (
                  <div key={int.id} className="flex items-start gap-3 p-3 bg-[var(--bg-secondary)] rounded-xl">
                    <div className="w-9 h-9 bg-brand-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Briefcase size={16} className="text-brand-500" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-[var(--text-primary)]">{int.company}</p>
                      <p className="text-xs text-[var(--text-muted)]">{int.date} · {int.time}</p>
                      <Badge variant={statusColors[int.status]} className="mt-1">{int.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-[var(--text-muted)] text-center py-4">No upcoming interviews</p>
            )}
          </Card>
        </div>
      </div>

      {/* Recent Activity */}
      <Card className="p-5">
        <h2 className="font-display font-bold text-lg text-[var(--text-primary)] mb-4">Recent Activity</h2>
        <div className="space-y-3">
          {mockActivities.map(act => (
            <div key={act.id} className="flex items-center gap-4 py-2">
              <div className="w-8 h-8 bg-[var(--bg-tertiary)] rounded-xl flex items-center justify-center text-base flex-shrink-0">
                {activityIcons[act.icon]}
              </div>
              <div className="flex-1">
                <p className="text-sm text-[var(--text-primary)]">{act.text}</p>
              </div>
              <span className="text-xs text-[var(--text-muted)] flex-shrink-0">{act.time}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
