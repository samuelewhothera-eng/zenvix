import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Sparkles, RefreshCw, Copy, ThumbsUp, ThumbsDown } from "lucide-react";
import { mockAIMessages, mockSuggestedPrompts } from "../data/mockData";
import { Avatar, Card } from "../components/ui";
import { useApp } from "../context/AppContext";
import { aiService } from "../services/api";
import { clsx } from "clsx";
import toast from "react-hot-toast";

const careerCards = [
  { title: "Interview Prep", desc: "Practice common technical and behavioral questions", emoji: "🎤", prompt: "Help me prepare for a React developer interview" },
  { title: "Resume Review", desc: "Get AI feedback on your resume", emoji: "📄", prompt: "Review my resume and suggest improvements" },
  { title: "Career Path", desc: "Explore career options based on your skills", emoji: "🗺️", prompt: "What career paths are available for a React developer?" },
  { title: "Salary Guide", desc: "Understand market rates in your region", emoji: "💰", prompt: "What is the average salary for a junior frontend developer in Nigeria?" },
];

function MessageBubble({ msg, user }) {
  const isUser = msg.role === "user";
  return (
    <div className={clsx("flex gap-3 items-start", isUser && "flex-row-reverse")}>
      {isUser ? (
        <Avatar src={user?.avatar} name={user?.name} size="sm" className="flex-shrink-0 mt-1" />
      ) : (
        <div className="w-8 h-8 bg-gradient-to-br from-brand-500 to-purple-500 rounded-xl flex items-center justify-center flex-shrink-0 mt-1">
          <Bot size={16} className="text-white" />
        </div>
      )}
      <div className={clsx("max-w-[80%] space-y-1", isUser && "items-end flex flex-col")}>
        <div className={clsx("px-4 py-3 rounded-2xl text-sm leading-relaxed",
          isUser
            ? "bg-brand-500 text-white rounded-tr-sm"
            : "bg-[var(--bg-secondary)] border border-[var(--border-color)] text-[var(--text-primary)] rounded-tl-sm"
        )}>
          {msg.content}
        </div>
        <div className={clsx("flex items-center gap-2 px-1", isUser && "flex-row-reverse")}>
          <span className="text-xs text-[var(--text-muted)]">{msg.time}</span>
          {!isUser && (
            <div className="flex items-center gap-1">
              <button onClick={() => { navigator.clipboard.writeText(msg.content); toast.success("Copied!"); }} className="w-5 h-5 flex items-center justify-center text-[var(--text-muted)] hover:text-[var(--text-primary)] transition-colors">
                <Copy size={11} />
              </button>
              <button onClick={() => toast.success("Thanks for the feedback!")} className="w-5 h-5 flex items-center justify-center text-[var(--text-muted)] hover:text-emerald-500 transition-colors"><ThumbsUp size={11} /></button>
              <button onClick={() => toast("We'll improve this!")} className="w-5 h-5 flex items-center justify-center text-[var(--text-muted)] hover:text-red-500 transition-colors"><ThumbsDown size={11} /></button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function TypingIndicator() {
  return (
    <div className="flex gap-3 items-start">
      <div className="w-8 h-8 bg-gradient-to-br from-brand-500 to-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
        <Bot size={16} className="text-white" />
      </div>
      <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] px-4 py-3 rounded-2xl rounded-tl-sm">
        <div className="flex items-center gap-1">
          {[0, 1, 2].map(i => (
            <div key={i} className="w-2 h-2 bg-brand-400 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default function AIAssistantPage() {
  const { user } = useApp();
  const [messages, setMessages] = useState(mockAIMessages);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    const content = text || input.trim();
    if (!content || loading) return;
    setInput("");

    const userMsg = { id: Date.now(), role: "user", content, time: "Just now" };
    setMessages(m => [...m, userMsg]);
    setLoading(true);

    const { data } = await aiService.chat([...messages, userMsg]);
    const aiMsg = { id: Date.now() + 1, role: "assistant", content: data.content, time: "Just now" };
    setMessages(m => [...m, aiMsg]);
    setLoading(false);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const clearChat = () => {
    setMessages(mockAIMessages);
    toast.success("Chat cleared");
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-8rem)] animate-fade-in">
      {/* Sidebar */}
      <div className="lg:w-72 flex-shrink-0 space-y-4 lg:overflow-y-auto">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles size={16} className="text-brand-500" />
            <h2 className="font-display font-bold text-base text-[var(--text-primary)]">AI Career Coach</h2>
          </div>
          <p className="text-xs text-[var(--text-muted)]">Powered by Zenvix AI</p>
        </div>

        {/* Career Quick Cards */}
        <div>
          <p className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-2">Quick Actions</p>
          <div className="space-y-2">
            {careerCards.map(card => (
              <button key={card.title} onClick={() => sendMessage(card.prompt)}
                className="w-full text-left card p-3 hover:shadow-card-hover hover:-translate-y-0.5 transition-all flex items-start gap-3">
                <span className="text-xl flex-shrink-0">{card.emoji}</span>
                <div>
                  <p className="font-semibold text-sm text-[var(--text-primary)]">{card.title}</p>
                  <p className="text-xs text-[var(--text-muted)] leading-snug">{card.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Suggested Prompts */}
        <div>
          <p className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-2">Suggested</p>
          <div className="space-y-1.5">
            {mockSuggestedPrompts.map(prompt => (
              <button key={prompt} onClick={() => sendMessage(prompt)}
                className="w-full text-left text-xs px-3 py-2 rounded-xl bg-[var(--bg-secondary)] border border-[var(--border-color)] text-[var(--text-secondary)] hover:border-brand-500/50 hover:text-[var(--text-primary)] hover:bg-brand-500/5 transition-all">
                {prompt}
              </button>
            ))}
          </div>
        </div>

        <button onClick={clearChat} className="btn-ghost w-full justify-center text-xs">
          <RefreshCw size={13} /> Clear Chat
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-h-0 card overflow-hidden">
        {/* Chat Header */}
        <div className="p-4 border-b border-[var(--border-color)] flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-brand-500 to-purple-500 rounded-xl flex items-center justify-center">
            <Bot size={18} className="text-white" />
          </div>
          <div>
            <p className="font-display font-bold text-sm text-[var(--text-primary)]">Zenvix AI</p>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
              <span className="text-xs text-emerald-500 font-medium">Online — ready to help</span>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map(msg => <MessageBubble key={msg.id} msg={msg} user={user} />)}
          {loading && <TypingIndicator />}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-[var(--border-color)]">
          <div className="flex items-end gap-3">
            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask anything about your career, skills, or interview prep..."
                rows={1}
                className="w-full px-4 py-3 pr-12 rounded-2xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 resize-none text-sm max-h-32 transition-all"
                style={{ minHeight: "48px" }}
              />
            </div>
            <button
              onClick={() => sendMessage()}
              disabled={!input.trim() || loading}
              className="w-12 h-12 bg-brand-500 hover:bg-brand-600 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-2xl flex items-center justify-center transition-all active:scale-95 shadow-sm hover:shadow-glow flex-shrink-0"
            >
              <Send size={18} />
            </button>
          </div>
          <p className="text-xs text-[var(--text-muted)] text-center mt-2">Press Enter to send · Shift+Enter for new line</p>
        </div>
      </div>
    </div>
  );
}
