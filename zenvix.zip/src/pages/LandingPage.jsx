// Landing Page - Investor-ready, modern startup aesthetic
import { Link } from "react-router-dom";
import { ArrowRight, Play, Zap, CheckCircle2, BookOpen, Award, Briefcase, MessageSquare, Star, Users, Globe, TrendingUp, Shield, Cpu, ChevronRight } from "lucide-react";
import { mockTestimonials, mockStats } from "../data/mockData";
import { StarRating, Badge } from "../components/ui";

const features = [
  {
    icon: BookOpen,
    title: "Structured Learning Paths",
    desc: "Curated courses from frontend to backend, design to data. Learn in order, build real projects.",
    color: "text-blue-500", bg: "bg-blue-500/10",
  },
  {
    icon: CheckCircle2,
    title: "Verified Skill Badges",
    desc: "Take timed assessments. Pass them. Employers trust our verification system.",
    color: "text-emerald-500", bg: "bg-emerald-500/10",
  },
  {
    icon: Award,
    title: "Blockchain Certificates",
    desc: "Download beautiful, verifiable certificates that prove your abilities to any employer globally.",
    color: "text-purple-500", bg: "bg-purple-500/10",
  },
  {
    icon: Briefcase,
    title: "Remote Job Matching",
    desc: "AI matches your verified skills to real remote jobs from companies hiring globally.",
    color: "text-orange-500", bg: "bg-orange-500/10",
  },
  {
    icon: MessageSquare,
    title: "AI Career Coach",
    desc: "24/7 AI assistant for interview prep, resume review, and career strategy advice.",
    color: "text-pink-500", bg: "bg-pink-500/10",
  },
  {
    icon: Users,
    title: "Peer Community",
    desc: "Connect with 48,000+ learners across Africa. Study groups, mentorship, and accountability.",
    color: "text-cyan-500", bg: "bg-cyan-500/10",
  },
];

const companies = ["Andela", "Flutterwave", "Paystack", "Jumia", "Safaricom", "OrangeAfrica", "Interswitch", "Techpoint"];

const stats = [
  { value: "48,200+", label: "Active Learners", icon: Users },
  { value: "320+", label: "Expert Courses", icon: BookOpen },
  { value: "18,900+", label: "Certificates Issued", icon: Award },
  { value: "240+", label: "Hiring Companies", icon: Briefcase },
];

const howItWorks = [
  { step: "01", title: "Create your free account", desc: "Sign up in 30 seconds. No credit card required.", icon: Zap },
  { step: "02", title: "Learn at your own pace", desc: "Access 320+ courses on web dev, design, data, and more.", icon: BookOpen },
  { step: "03", title: "Get verified & certified", desc: "Pass assessments and earn blockchain-backed certificates.", icon: Award },
  { step: "04", title: "Land your remote job", desc: "AI matches you to jobs based on your verified skills.", icon: Briefcase },
];

export default function LandingPage() {
  return (
    <div className="overflow-hidden">
      {/* ===== HERO ===== */}
      <section className="relative min-h-screen flex items-center bg-[var(--bg-primary)] pt-8 pb-20">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-96 h-96 bg-brand-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-brand-500/5 to-transparent rounded-full" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left */}
            <div className="animate-slide-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-500/10 rounded-full text-brand-600 dark:text-brand-400 text-sm font-semibold mb-6 border border-brand-500/20">
                <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                🌍 Empowering Africa's Digital Workforce
              </div>
              
              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-[var(--text-primary)] leading-[1.05] mb-6">
                Learn Skills.<br />
                Get Verified.<br />
                <span className="bg-gradient-to-r from-brand-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                  Get Hired.
                </span>
              </h1>
              
              <p className="text-lg text-[var(--text-secondary)] leading-relaxed mb-8 max-w-lg">
                Zenvix turns ambitious students into verified digital professionals. 
                Learn real skills, earn trusted certificates, and connect with remote jobs 
                at top companies globally — all in one platform.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-3 mb-10">
                <Link to="/register" className="btn-primary text-base px-7 py-3.5 shadow-glow">
                  Start Learning Free <ArrowRight size={18} />
                </Link>
                <Link to="/courses" className="btn-secondary text-base px-7 py-3.5">
                  <Play size={18} className="text-brand-500" /> Browse Courses
                </Link>
              </div>

              {/* Social Proof */}
              <div className="flex items-center gap-4">
                <div className="flex -space-x-2">
                  {[1,2,3,4,5].map(i => (
                    <img key={i} src={`https://api.dicebear.com/7.x/avataaars/svg?seed=user${i}&backgroundColor=dbeafe,fce7f3,d1fae5`} alt="" className="w-9 h-9 rounded-full border-2 border-[var(--bg-primary)]" />
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1 mb-0.5">
                    {[1,2,3,4,5].map(i => <Star key={i} size={13} className="fill-amber-400 text-amber-400" />)}
                    <span className="text-sm font-bold text-[var(--text-primary)] ml-1">4.9</span>
                  </div>
                  <p className="text-xs text-[var(--text-muted)]">Loved by 48,200+ learners</p>
                </div>
              </div>
            </div>

            {/* Right - Hero Dashboard Preview */}
            <div className="relative animate-slide-up stagger-2 hidden lg:block">
              <div className="relative">
                {/* Main card */}
                <div className="bg-[var(--card-bg)] border border-[var(--border-color)] rounded-3xl shadow-2xl p-6 animate-float">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <p className="text-sm text-[var(--text-muted)]">Welcome back,</p>
                      <p className="font-display font-bold text-xl text-[var(--text-primary)]">Amara 👋</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-[var(--text-muted)]">Daily Streak</p>
                      <p className="font-display font-bold text-2xl text-brand-500">🔥 12</p>
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="bg-[var(--bg-secondary)] rounded-2xl p-4 mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="font-semibold text-[var(--text-primary)]">React Bootcamp</span>
                      <span className="text-brand-500 font-bold">68%</span>
                    </div>
                    <div className="h-2.5 bg-[var(--bg-tertiary)] rounded-full overflow-hidden">
                      <div className="h-full w-[68%] bg-gradient-to-r from-brand-500 to-brand-400 rounded-full" />
                    </div>
                  </div>

                  {/* Stats row */}
                  <div className="grid grid-cols-3 gap-3">
                    {[{ label: "Courses", val: "4", icon: "📚" },{ label: "Certs", val: "3", icon: "🏆" },{ label: "XP", val: "2.8K", icon: "⚡" }].map(s => (
                      <div key={s.label} className="bg-[var(--bg-secondary)] rounded-xl p-3 text-center">
                        <div className="text-xl mb-0.5">{s.icon}</div>
                        <div className="font-display font-bold text-base text-[var(--text-primary)]">{s.val}</div>
                        <div className="text-xs text-[var(--text-muted)]">{s.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Floating notification */}
                <div className="absolute -top-4 -right-4 bg-emerald-500 text-white text-xs font-bold px-3 py-2 rounded-xl shadow-lg animate-bounce-subtle flex items-center gap-1.5">
                  <CheckCircle2 size={14} /> Certificate Earned!
                </div>

                {/* Job match card */}
                <div className="absolute -bottom-4 -left-4 bg-[var(--card-bg)] border border-[var(--border-color)] rounded-2xl shadow-xl p-4 max-w-52 animate-float" style={{ animationDelay: "3s" }}>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 bg-blue-500/20 rounded-lg" />
                    <span className="text-xs font-bold text-[var(--text-primary)]">New Job Match</span>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)]">Junior Dev at Andela</p>
                  <p className="text-xs text-emerald-500 font-bold mt-1">94% skill match ✨</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== COMPANY LOGOS ===== */}
      <section className="py-12 border-y border-[var(--border-color)] bg-[var(--bg-secondary)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-center text-sm text-[var(--text-muted)] font-medium mb-8">
            Trusted by top companies hiring from our platform
          </p>
          <div className="flex flex-wrap justify-center gap-6 md:gap-10">
            {companies.map(company => (
              <div key={company} className="text-[var(--text-muted)] font-display font-bold text-sm opacity-50 hover:opacity-100 transition-opacity">
                {company}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== STATS ===== */}
      <section className="py-20 bg-[var(--bg-primary)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div key={stat.label} className={`text-center animate-slide-up stagger-${i + 1}`}>
                <div className="font-display text-4xl md:text-5xl font-bold bg-gradient-to-r from-brand-500 to-purple-500 bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <p className="text-sm text-[var(--text-secondary)] font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FEATURES ===== */}
      <section id="features" className="py-20 bg-[var(--bg-secondary)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <Badge variant="blue" className="mb-4">Everything You Need</Badge>
            <h2 className="section-title text-4xl mb-4">One platform, your entire career journey</h2>
            <p className="section-subtitle">From your first line of code to landing your first remote job — Zenvix has every tool you need.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feat, i) => (
              <div key={feat.title} className={`card p-6 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 animate-slide-up stagger-${i + 1}`}>
                <div className={`w-12 h-12 ${feat.bg} ${feat.color} rounded-2xl flex items-center justify-center mb-4`}>
                  <feat.icon size={22} />
                </div>
                <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-2">{feat.title}</h3>
                <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== HOW IT WORKS ===== */}
      <section className="py-20 bg-[var(--bg-primary)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <Badge variant="green" className="mb-4">Simple Process</Badge>
            <h2 className="section-title text-4xl mb-4">From zero to hired in 4 steps</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {howItWorks.map((step, i) => (
              <div key={step.step} className="relative">
                {i < howItWorks.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-px bg-gradient-to-r from-[var(--border-color)] to-transparent z-0" />
                )}
                <div className="relative z-10">
                  <div className="text-5xl font-display font-black text-[var(--bg-tertiary)] mb-3">{step.step}</div>
                  <div className="w-14 h-14 bg-gradient-to-br from-brand-500 to-purple-500 rounded-2xl flex items-center justify-center mb-4 shadow-glow">
                    <step.icon size={24} className="text-white" />
                  </div>
                  <h3 className="font-display font-bold text-lg text-[var(--text-primary)] mb-2">{step.title}</h3>
                  <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== TESTIMONIALS ===== */}
      <section className="py-20 bg-[var(--bg-secondary)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <Badge variant="purple" className="mb-4">Success Stories</Badge>
            <h2 className="section-title text-4xl mb-4">Real people, real results</h2>
            <p className="section-subtitle">Join thousands who transformed their careers with Zenvix.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {mockTestimonials.map((t, i) => (
              <div key={t.id} className={`card p-6 animate-slide-up stagger-${i + 1}`}>
                <div className="flex items-start gap-3 mb-4">
                  <img src={t.avatar} alt={t.name} className="w-12 h-12 rounded-xl" />
                  <div>
                    <p className="font-display font-bold text-sm text-[var(--text-primary)]">{t.name}</p>
                    <p className="text-xs text-[var(--text-secondary)]">{t.role}</p>
                    <p className="text-xs text-[var(--text-muted)]">{t.country}</p>
                  </div>
                </div>
                <StarRating rating={t.rating} />
                <p className="text-sm text-[var(--text-secondary)] leading-relaxed mt-3 italic">"{t.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section className="py-20 bg-gradient-to-br from-brand-600 to-purple-700 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)", backgroundSize: "30px 30px" }} />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 rounded-full text-white text-sm font-semibold mb-6">
            <Zap size={14} /> Free to start, forever
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-white mb-4 leading-tight">
            Your future starts today
          </h2>
          <p className="text-white/80 text-lg mb-8 leading-relaxed">
            Join 48,200+ students already on Zenvix. No credit card needed. Start learning in 60 seconds.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/register" className="inline-flex items-center justify-center gap-2 bg-white text-brand-600 font-bold px-8 py-4 rounded-xl hover:bg-gray-50 transition-colors text-base shadow-xl">
              Create Free Account <ArrowRight size={18} />
            </Link>
            <Link to="/courses" className="inline-flex items-center justify-center gap-2 bg-white/20 text-white font-bold px-8 py-4 rounded-xl hover:bg-white/30 transition-colors text-base border border-white/30">
              Browse 320+ Courses
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
