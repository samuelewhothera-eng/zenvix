import { useState } from "react";
import { Users, Briefcase, TrendingUp, Eye, MessageSquare, CheckCircle2, Plus, BarChart2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { mockApplicants, mockJobs } from "../data/mockData";
import { Card, Badge, Button, Avatar, StatCard } from "../components/ui";
import toast from "react-hot-toast";

const statusColors = { New: "blue", Reviewed: "orange", Interview: "green", Rejected: "red" };

const hiringData = [
  { month: "Jan", applications: 12, hired: 2 },
  { month: "Feb", applications: 28, hired: 4 },
  { month: "Mar", applications: 45, hired: 6 },
  { month: "Apr", applications: 38, hired: 5 },
  { month: "May", applications: 62, hired: 8 },
];

const tabs = ["overview", "applicants", "jobs", "post-job"];

function PostJobForm() {
  const [form, setForm] = useState({ title: "", type: "Full-time", category: "Frontend", salary: "", desc: "", skills: "" });
  const [submitting, setSubmitting] = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 1000));
    setSubmitting(false);
    toast.success("Job posted successfully! 🎉");
    setForm({ title: "", type: "Full-time", category: "Frontend", salary: "", desc: "", skills: "" });
  };

  return (
    <Card className="p-6">
      <h2 className="font-display font-bold text-xl text-[var(--text-primary)] mb-6">Post a New Job</h2>
      <form onSubmit={handle} className="space-y-5">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-semibold text-[var(--text-primary)] mb-1.5 block">Job Title *</label>
            <input value={form.title} onChange={e => setForm(f=>({...f,title:e.target.value}))} required placeholder="e.g. Junior Frontend Developer"
              className="w-full px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 text-sm" />
          </div>
          <div>
            <label className="text-sm font-semibold text-[var(--text-primary)] mb-1.5 block">Salary Range</label>
            <input value={form.salary} onChange={e => setForm(f=>({...f,salary:e.target.value}))} placeholder="e.g. $800 - $1,200/mo"
              className="w-full px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 text-sm" />
          </div>
          <div>
            <label className="text-sm font-semibold text-[var(--text-primary)] mb-1.5 block">Job Type</label>
            <select value={form.type} onChange={e => setForm(f=>({...f,type:e.target.value}))}
              className="w-full px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] focus:outline-none text-sm cursor-pointer">
              {["Full-time","Part-time","Contract","Internship"].map(t=><option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold text-[var(--text-primary)] mb-1.5 block">Category</label>
            <select value={form.category} onChange={e => setForm(f=>({...f,category:e.target.value}))}
              className="w-full px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] focus:outline-none text-sm cursor-pointer">
              {["Frontend","Backend","Design","Data","Marketing","DevOps"].map(c=><option key={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="text-sm font-semibold text-[var(--text-primary)] mb-1.5 block">Required Skills (comma-separated)</label>
          <input value={form.skills} onChange={e => setForm(f=>({...f,skills:e.target.value}))} placeholder="React, JavaScript, CSS, Git"
            className="w-full px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 text-sm" />
        </div>
        <div>
          <label className="text-sm font-semibold text-[var(--text-primary)] mb-1.5 block">Job Description</label>
          <textarea value={form.desc} onChange={e => setForm(f=>({...f,desc:e.target.value}))} rows={5} required placeholder="Describe the role, responsibilities, and what you're looking for..."
            className="w-full px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 text-sm resize-none" />
        </div>
        <div className="flex gap-3">
          <Button type="submit" variant="primary" className="flex-1 justify-center py-3" loading={submitting}>
            <Plus size={16} /> Post Job
          </Button>
          <Button variant="secondary" type="button" onClick={() => toast("Draft saved!")}>Save Draft</Button>
        </div>
      </form>
    </Card>
  );
}

export default function EmployerDashboard() {
  const [tab, setTab] = useState("overview");
  const [applicantStatus, setApplicantStatus] = useState({});

  const updateStatus = (id, status) => {
    setApplicantStatus(s => ({ ...s, [id]: status }));
    toast.success(`Status updated to ${status}`);
  };

  const stats = [
    { label: "Active Jobs", value: "3", change: 0, icon: Briefcase, color: "blue" },
    { label: "Total Applicants", value: "43", change: 28, icon: Users, color: "green" },
    { label: "Interviews Scheduled", value: "8", change: 14, icon: MessageSquare, color: "purple" },
    { label: "Hires This Month", value: "2", change: 100, icon: CheckCircle2, color: "orange" },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-[var(--text-primary)]">Employer Dashboard</h1>
          <p className="text-[var(--text-secondary)]">Manage jobs and find verified talent</p>
        </div>
        <Button variant="primary" onClick={() => setTab("post-job")}>
          <Plus size={16} /> Post New Job
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl p-1.5 overflow-x-auto">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold transition-all capitalize ${tab === t ? "bg-[var(--card-bg)] text-[var(--text-primary)] shadow-sm" : "text-[var(--text-muted)] hover:text-[var(--text-secondary)]"}`}>
            {t.replace("-", " ")}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map(s => <StatCard key={s.label} {...s} />)}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-5">
              <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4">Applications This Month</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={hiringData}>
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Tooltip contentStyle={{ background: "var(--card-bg)", border: "1px solid var(--border-color)", borderRadius: "10px", fontSize: "12px" }} />
                  <Bar dataKey="applications" fill="#0ea5e9" radius={[6,6,0,0]} name="Applications" />
                  <Bar dataKey="hired" fill="#10b981" radius={[6,6,0,0]} name="Hired" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-5">
              <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4">Top Active Jobs</h3>
              <div className="space-y-3">
                {mockJobs.slice(0, 3).map(job => (
                  <div key={job.id} className="flex items-center gap-3 p-3 bg-[var(--bg-secondary)] rounded-xl">
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-[var(--text-primary)] truncate">{job.title}</p>
                      <p className="text-xs text-[var(--text-muted)]">{job.applicants} applicants · {job.posted}</p>
                    </div>
                    <Badge variant="blue">{job.type}</Badge>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      )}

      {tab === "applicants" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-xl text-[var(--text-primary)]">Candidate Applications</h2>
            <Badge variant="blue">{mockApplicants.length} total</Badge>
          </div>
          {mockApplicants.map(app => {
            const currentStatus = applicantStatus[app.id] || app.status;
            return (
              <Card key={app.id} className="p-5">
                <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                  <div className="flex items-center gap-4 flex-1">
                    <Avatar src={app.avatar} name={app.name} size="lg" />
                    <div>
                      <h3 className="font-display font-bold text-base text-[var(--text-primary)]">{app.name}</h3>
                      <p className="text-xs text-[var(--text-muted)] mb-2">{app.location}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {app.skills.map(s => <span key={s} className="px-2 py-0.5 bg-brand-500/10 text-brand-600 dark:text-brand-400 text-xs rounded-md font-medium">{s}</span>)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="text-center">
                      <div className="text-xl font-black text-emerald-500">{app.matchScore}%</div>
                      <div className="text-xs text-[var(--text-muted)]">Match</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-black text-brand-500">{app.certificates}</div>
                      <div className="text-xs text-[var(--text-muted)]">Certs</div>
                    </div>
                    <Badge variant={statusColors[currentStatus] || "gray"}>{currentStatus}</Badge>
                    <div className="flex gap-2">
                      <Button variant="primary" className="text-xs py-2 px-3" onClick={() => updateStatus(app.id, "Interview")}>
                        <Eye size={12} /> Schedule
                      </Button>
                      <Button variant="secondary" className="text-xs py-2 px-3" onClick={() => updateStatus(app.id, "Reviewed")}>
                        Review
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {tab === "jobs" && (
        <div className="space-y-4">
          <h2 className="font-display font-bold text-xl text-[var(--text-primary)]">Your Posted Jobs</h2>
          {mockJobs.slice(0, 3).map(job => (
            <Card key={job.id} className="p-5 flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex-1">
                <h3 className="font-display font-bold text-base text-[var(--text-primary)]">{job.title}</h3>
                <p className="text-sm text-[var(--text-secondary)] mt-0.5">{job.type} · {job.location} · {job.salary}</p>
                <p className="text-xs text-[var(--text-muted)] mt-1">{job.applicants} applicants · Posted {job.posted}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" className="text-xs py-2 px-3">Edit</Button>
                <Button variant="ghost" className="text-xs py-2 px-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10" onClick={() => toast.success("Job closed")}>Close</Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab === "post-job" && <PostJobForm />}
    </div>
  );
}
