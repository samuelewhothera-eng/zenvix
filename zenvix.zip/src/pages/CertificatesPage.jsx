import { useState } from "react";
import { Award, Download, Share2, ExternalLink, CheckCircle2, Shield, Zap } from "lucide-react";
import { mockCertificates } from "../data/mockData";
import { Card, Badge, Button, Modal } from "../components/ui";
import { clsx } from "clsx";
import toast from "react-hot-toast";

const gradeColors = { Distinction: "purple", Merit: "blue", Pass: "green" };

function CertificatePreview({ cert, onClose }) {
  return (
    <div className="space-y-4">
      {/* Certificate Visual */}
      <div className="relative bg-gradient-to-br from-[#0a0f2e] to-[#1a1040] rounded-2xl overflow-hidden p-8 text-center border-2 border-amber-400/30 shadow-2xl">
        {/* Corner decorations */}
        <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-amber-400/60 rounded-tl-lg" />
        <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-amber-400/60 rounded-tr-lg" />
        <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-amber-400/60 rounded-bl-lg" />
        <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-amber-400/60 rounded-br-lg" />

        {/* Background pattern */}
        <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "radial-gradient(circle, gold 1px, transparent 1px)", backgroundSize: "20px 20px" }} />

        <div className="relative z-10">
          {/* Logo */}
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
              <Zap size={16} className="text-white" />
            </div>
            <span className="font-display font-bold text-white text-lg">Zenvix Academy</span>
          </div>

          <p className="text-amber-400/80 text-xs font-semibold tracking-[0.2em] uppercase mb-3">Certificate of Achievement</p>

          <p className="text-white/70 text-sm mb-2">This certifies that</p>
          <h2 className="font-display text-3xl font-bold text-white mb-2">{cert.recipientName}</h2>
          <p className="text-white/70 text-sm mb-3">has successfully completed</p>
          <h3 className="font-display text-xl font-bold text-amber-300 mb-4 px-8">{cert.title}</h3>

          <div className="flex items-center justify-center gap-2 mb-4">
            <Badge variant="purple">{cert.grade}</Badge>
            <Badge variant="blue">Score: {cert.score}%</Badge>
          </div>

          {/* Skills */}
          <div className="flex flex-wrap justify-center gap-1.5 mb-5">
            {cert.skills.map(s => (
              <span key={s} className="px-2.5 py-1 bg-white/10 text-white/70 text-xs rounded-lg border border-white/10">{s}</span>
            ))}
          </div>

          {/* Footer info */}
          <div className="flex items-center justify-between pt-4 border-t border-white/10">
            <div className="text-left">
              <p className="text-white/50 text-xs">Issued</p>
              <p className="text-white text-xs font-semibold">{cert.issuedDate}</p>
            </div>
            <div className="w-12 h-12 bg-emerald-500/20 rounded-full flex items-center justify-center border-2 border-emerald-500/40">
              <CheckCircle2 size={20} className="text-emerald-400" />
            </div>
            <div className="text-right">
              <p className="text-white/50 text-xs">Credential ID</p>
              <p className="text-amber-300 text-xs font-mono font-semibold">{cert.verificationId}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <Button variant="primary" className="flex-1 justify-center" onClick={() => { toast.success("Certificate downloaded!"); onClose(); }}>
          <Download size={16} /> Download PDF
        </Button>
        <Button variant="secondary" onClick={() => { toast.success("Share link copied!"); }}>
          <Share2 size={16} /> Share
        </Button>
      </div>

      {/* Verification */}
      <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3">
        <Shield size={16} className="text-emerald-500 flex-shrink-0" />
        <div>
          <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">Blockchain Verified</p>
          <p className="text-xs text-[var(--text-muted)]">Verify at: zenvix.io/verify/{cert.verificationId}</p>
        </div>
        <button className="ml-auto" onClick={() => toast.success("Verification link copied!")}>
          <ExternalLink size={14} className="text-emerald-500" />
        </button>
      </div>
    </div>
  );
}

export default function CertificatesPage() {
  const [selectedCert, setSelectedCert] = useState(null);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-[var(--text-primary)] mb-1">My Certificates</h1>
          <p className="text-[var(--text-secondary)]">{mockCertificates.length} certificates earned — share them with employers</p>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Earned", value: mockCertificates.length, icon: "🏆" },
          { label: "Shared", value: 2, icon: "📤" },
          { label: "Verified Views", value: 47, icon: "👁️" },
        ].map(s => (
          <Card key={s.label} className="p-4 text-center">
            <div className="text-2xl mb-1">{s.icon}</div>
            <p className="font-display font-bold text-2xl text-[var(--text-primary)]">{s.value}</p>
            <p className="text-xs text-[var(--text-muted)]">{s.label}</p>
          </Card>
        ))}
      </div>

      {/* Certificates Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {mockCertificates.map(cert => (
          <Card key={cert.id} hover className="overflow-hidden" onClick={() => setSelectedCert(cert)}>
            {/* Certificate mini preview */}
            <div className="bg-gradient-to-br from-[#0a0f2e] to-[#1a1040] p-6 text-center relative overflow-hidden">
              <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "radial-gradient(circle, gold 1px, transparent 1px)", backgroundSize: "15px 15px" }} />
              <div className="relative z-10">
                <div className="w-12 h-12 bg-amber-400/20 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Award size={24} className="text-amber-400" />
                </div>
                <p className="text-white/60 text-xs mb-1">Certificate of Achievement</p>
                <p className="text-amber-300 font-display font-bold text-sm leading-snug">{cert.title}</p>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Badge variant={gradeColors[cert.grade] || "blue"}>{cert.grade}</Badge>
                <span className="text-xs text-[var(--text-muted)]">{cert.issuedDate}</span>
              </div>
              <p className="text-xs font-mono text-[var(--text-muted)] mb-3">{cert.verificationId}</p>
              <div className="flex flex-wrap gap-1 mb-3">
                {cert.skills.slice(0, 3).map(s => (
                  <span key={s} className="px-2 py-0.5 bg-[var(--bg-tertiary)] text-[var(--text-secondary)] text-xs rounded-md">{s}</span>
                ))}
              </div>
              <div className="flex gap-2">
                <button className="flex-1 btn-primary text-xs py-2 justify-center" onClick={e => { e.stopPropagation(); toast.success("Downloaded!"); }}>
                  <Download size={12} /> Download
                </button>
                <button className="btn-secondary text-xs py-2 px-3" onClick={e => { e.stopPropagation(); toast.success("Share link copied!"); }}>
                  <Share2 size={12} />
                </button>
              </div>
            </div>
          </Card>
        ))}

        {/* Empty - earn more */}
        <Card className="p-6 border-dashed flex flex-col items-center justify-center text-center min-h-48 hover:border-brand-500/50 transition-colors cursor-pointer" onClick={() => window.location.href="/verify"}>
          <div className="w-12 h-12 bg-brand-500/10 rounded-2xl flex items-center justify-center mb-3">
            <Award size={22} className="text-brand-500" />
          </div>
          <p className="font-semibold text-[var(--text-primary)] text-sm mb-1">Earn Another Certificate</p>
          <p className="text-xs text-[var(--text-muted)]">Pass an assessment to unlock</p>
        </Card>
      </div>

      {/* Modal */}
      {selectedCert && (
        <Modal isOpen={!!selectedCert} onClose={() => setSelectedCert(null)} title="Certificate Details" size="md">
          <CertificatePreview cert={selectedCert} onClose={() => setSelectedCert(null)} />
        </Modal>
      )}
    </div>
  );
}
