import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, Filter, BookOpen, Users, Clock, Star, Lock, CheckCircle2, Play } from "lucide-react";
import { mockCourses, categories, levels } from "../data/mockData";
import { Card, Badge, ProgressBar, StarRating } from "../components/ui";
import { CourseCardSkeleton } from "../components/skeletons";

const categoryColors = {
  Frontend: "blue", Backend: "green", Design: "purple",
  Data: "orange", Security: "red", Marketing: "yellow", DevOps: "gray",
};
const levelColors = { Beginner: "green", Intermediate: "orange", Advanced: "red" };

function CourseCard({ course }) {
  return (
    <Link to={`/courses/${course.id}`}>
      <Card hover className="overflow-hidden h-full flex flex-col">
        <div className="relative">
          <img src={course.thumbnail} alt={course.title} className="w-full h-44 object-cover" />
          {course.isPremium && (
            <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-amber-500 text-white text-xs font-bold px-2.5 py-1 rounded-lg">
              <Lock size={11} /> Pro
            </div>
          )}
          {course.isEnrolled && course.progress === 100 && (
            <div className="absolute top-3 right-3 w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center">
              <CheckCircle2 size={16} className="text-white" />
            </div>
          )}
        </div>
        <div className="p-5 flex flex-col flex-1">
          <div className="flex items-center gap-2 mb-2">
            <Badge variant={categoryColors[course.category] || "blue"}>{course.category}</Badge>
            <Badge variant={levelColors[course.level] || "gray"}>{course.level}</Badge>
          </div>
          <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-1 line-clamp-2 leading-snug">{course.title}</h3>
          <p className="text-xs text-[var(--text-muted)] mb-3">by {course.instructor}</p>
          <div className="flex items-center gap-3 text-xs text-[var(--text-secondary)] mb-3">
            <span className="flex items-center gap-1"><Clock size={12} />{course.duration}</span>
            <span className="flex items-center gap-1"><BookOpen size={12} />{course.lessons} lessons</span>
            <span className="flex items-center gap-1"><Users size={12} />{course.students.toLocaleString()}</span>
          </div>
          <StarRating rating={course.rating} reviews={course.reviews} />
          {course.isEnrolled && course.progress > 0 && (
            <div className="mt-3 pt-3 border-t border-[var(--border-color)]">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[var(--text-muted)]">Progress</span>
                <span className="font-bold text-brand-500">{course.progress}%</span>
              </div>
              <ProgressBar value={course.progress} />
            </div>
          )}
          <div className="mt-auto pt-4">
            {course.isEnrolled ? (
              <div className="btn-primary w-full justify-center text-sm py-2.5">
                <Play size={14} /> {course.progress === 100 ? "Review Course" : "Continue"}
              </div>
            ) : (
              <div className="btn-secondary w-full justify-center text-sm py-2.5">
                {course.isPremium ? <><Lock size={14} /> Unlock — Pro</> : "Enroll Free"}
              </div>
            )}
          </div>
        </div>
      </Card>
    </Link>
  );
}

export default function CoursesPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [level, setLevel] = useState("All Levels");
  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    const t = setTimeout(() => {
      let filtered = [...mockCourses];
      if (category !== "All") filtered = filtered.filter(c => c.category === category);
      if (level !== "All Levels") filtered = filtered.filter(c => c.level === level);
      if (search) {
        const q = search.toLowerCase();
        filtered = filtered.filter(c => c.title.toLowerCase().includes(q) || c.tags.some(t => t.toLowerCase().includes(q)));
      }
      setCourses(filtered);
      setLoading(false);
    }, 500);
    return () => clearTimeout(t);
  }, [search, category, level]);

  useEffect(() => { setLoading(true); }, [search, category, level]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-3xl font-bold text-[var(--text-primary)] mb-1">Explore Courses</h1>
        <p className="text-[var(--text-secondary)]">Master in-demand skills with {mockCourses.length}+ expert-led courses</p>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search courses, skills, topics..."
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all text-sm"
          />
        </div>
        <select value={level} onChange={e => setLevel(e.target.value)}
          className="px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 text-sm cursor-pointer min-w-36">
          {levels.map(l => <option key={l}>{l}</option>)}
        </select>
      </div>

      {/* Category tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {categories.map(cat => (
          <button key={cat} onClick={() => setCategory(cat)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${category === cat ? "bg-brand-500 text-white shadow-sm" : "bg-[var(--bg-secondary)] text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] border border-[var(--border-color)]"}`}>
            {cat}
          </button>
        ))}
      </div>

      {/* Results count */}
      {!loading && (
        <p className="text-sm text-[var(--text-muted)]">
          Showing <span className="font-bold text-[var(--text-primary)]">{courses.length}</span> courses
          {category !== "All" && <> in <span className="text-brand-500">{category}</span></>}
        </p>
      )}

      {/* Course Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading
          ? Array(6).fill(0).map((_, i) => <CourseCardSkeleton key={i} />)
          : courses.length > 0
            ? courses.map(course => <CourseCard key={course.id} course={course} />)
            : (
              <div className="col-span-full text-center py-16">
                <BookOpen size={40} className="text-[var(--text-muted)] mx-auto mb-3" />
                <h3 className="font-display font-bold text-lg text-[var(--text-primary)] mb-1">No courses found</h3>
                <p className="text-[var(--text-secondary)] text-sm">Try a different search or filter</p>
              </div>
            )
        }
      </div>
    </div>
  );
}
