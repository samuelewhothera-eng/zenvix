import { useState } from "react";
import { Users, BookOpen, Briefcase, TrendingUp, Shield, AlertTriangle, CheckCircle2, XCircle, BarChart2, DollarSign } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { mockAdminStats, mockCourses, mockJobs } from "../data/mockData";
import { Card, Badge, Button, StatCard } from "../components/ui";
import toast from "react-hot-toast";

const COLORS = ["#0ea5e9", "#d946ef", "#10b981", "#f59e0b", "#6366f1"];

const categoryBreakdown = [
  { name: "Frontend", value: 35 }, { name: "Backend", value: 25 },
  { name: "Design", value: 20 }, { name: "Data", value: 12 }, { name: "Other", value: 8 },
];

const recentUsers = [
  { id: 1, name: "Chibuike Eze", email: "chibuike@ex.com", role: "Student", joined: "2 hours ago", status: "Active" },
  { id: 2, name: "Amina Diallo", email: "amina@ex.com", role: "Student", joined: "5 hours ago", status: "Active" },
  { id: 3, name: "TechCorp Ltd", email: "hr@techcorp.io", role: "Employer", joined: "1 day ago", status: "Pending" },
  { id: 4, name: "Grace Osei", email: "grace@ex.com", role: "Student", joined: "2 days ago", status: "Active" },
];

const tabs = ["overview", "users", "courses", "analytics", "security"];

export default function AdminDashboard() {
  const [tab, setTab] = useState("overview");

  const stats = [
    { label: "Total Users", value: mockAdminStats.totalUsers.toLocaleString(), change: 18, icon: Users, color: "blue" },
    { label: "Active Learners", value: mockAdminStats.activeLearners.toLocaleString(), change: 12, icon: TrendingUp, color: "green" },
    { label: "Courses", value: mockAdminStats.totalCourses, change: 5, icon: BookOpen, color: "purple" },
    { label: "Revenue (MTD)", value: `$${mockAdminStats.revenue.toLocaleString()}`, change: 22, icon: DollarSign, color: "orange" },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h1 className="font-display text-3xl font-bold text-[var(--text-primary)]">Admin Panel</h1>
            <Badge variant="red"><Shield size={11} /> Admin</Badge>
          </div>
          <p className="text-[var(--text-secondary)]">Platform management and analytics overview</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl p-1.5 overflow-x-auto">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold transition-all capitalize ${tab === t ? "bg-[var(--card-bg)] text-[var(--text-primary)] shadow-sm" : "text-[var(--text-muted)] hover:text-[var(--text-secondary)]"}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map(s => <StatCard key={s.label} {...s} />)}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="p-5">
                <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4">User Growth</h3>
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={mockAdminStats.userGrowth}>
                    <defs>
                      <linearGradient id="adminGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--text-muted)" }} axisLine={false} tickLine={false} />
                    <YAxis hide />
                    <Tooltip contentStyle={{ background: "var(--card-bg)", border: "1px solid var(--border-color)", borderRadius: "10px", fontSize: "12px" }} />
                    <Area type="monotone" dataKey="users" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#adminGrad)" name="Users" />
                  </AreaChart>
                </ResponsiveContainer>
              </Card>
            </div>

            <Card className="p-5">
              <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4">Course Categories</h3>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={categoryBreakdown} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                    {categoryBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => `${v}%`} contentStyle={{ background: "var(--card-bg)", border: "1px solid var(--border-color)", borderRadius: "10px", fontSize: "12px" }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {categoryBreakdown.map((c, i) => (
                  <div key={c.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                      <span className="text-[var(--text-secondary)]">{c.name}</span>
                    </div>
                    <span className="font-bold text-[var(--text-primary)]">{c.value}%</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Platform Health */}
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { label: "Server Uptime", value: "99.9%", status: "healthy", icon: CheckCircle2 },
              { label: "API Response", value: "124ms avg", status: "healthy", icon: TrendingUp },
              { label: "Pending Reports", value: "3 flagged", status: "warning", icon: AlertTriangle },
            ].map(item => (
              <Card key={item.label} className="p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.status === "healthy" ? "bg-emerald-500/10 text-emerald-500" : "bg-amber-500/10 text-amber-500"}`}>
                  <item.icon size={18} />
                </div>
                <div>
                  <p className="text-xs text-[var(--text-muted)]">{item.label}</p>
                  <p className="font-bold text-sm text-[var(--text-primary)]">{item.value}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {tab === "users" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-xl text-[var(--text-primary)]">Recent Users</h2>
            <Badge variant="blue">{mockAdminStats.totalUsers.toLocaleString()} total</Badge>
          </div>
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[var(--border-color)] bg-[var(--bg-secondary)]">
                    {["Name", "Email", "Role", "Joined", "Status", "Actions"].map(h => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-bold text-[var(--text-muted)] uppercase tracking-wide">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border-color)]">
                  {recentUsers.map(user => (
                    <tr key={user.id} className="hover:bg-[var(--bg-secondary)] transition-colors">
                      <td className="px-4 py-3 font-semibold text-sm text-[var(--text-primary)]">{user.name}</td>
                      <td className="px-4 py-3 text-sm text-[var(--text-secondary)]">{user.email}</td>
                      <td className="px-4 py-3"><Badge variant={user.role === "Employer" ? "purple" : "blue"}>{user.role}</Badge></td>
                      <td className="px-4 py-3 text-xs text-[var(--text-muted)]">{user.joined}</td>
                      <td className="px-4 py-3"><Badge variant={user.status === "Active" ? "green" : "orange"}>{user.status}</Badge></td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          <button className="text-xs px-2.5 py-1 rounded-lg bg-[var(--bg-tertiary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors font-medium" onClick={() => toast.success("Viewing user")}>View</button>
                          <button className="text-xs px-2.5 py-1 rounded-lg bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-colors font-medium" onClick={() => toast("User suspended")}>Suspend</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {tab === "courses" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-xl text-[var(--text-primary)]">Manage Courses</h2>
            <Button variant="primary" onClick={() => toast.success("Course creation coming soon!")}>+ Add Course</Button>
          </div>
          {mockCourses.slice(0, 4).map(course => (
            <Card key={course.id} className="p-4 flex flex-col sm:flex-row sm:items-center gap-4">
              <img src={course.thumbnail} alt={course.title} className="w-16 h-12 rounded-xl object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm text-[var(--text-primary)] truncate">{course.title}</p>
                <p className="text-xs text-[var(--text-muted)]">{course.instructor} · {course.students.toLocaleString()} students</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="green">Published</Badge>
                <button className="text-xs px-2.5 py-1.5 rounded-lg bg-[var(--bg-tertiary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] font-medium" onClick={() => toast.success("Editing course")}>Edit</button>
                <button className="text-xs px-2.5 py-1.5 rounded-lg bg-red-500/10 text-red-500 font-medium" onClick={() => toast("Course unpublished")}>Unpublish</button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {(tab === "analytics" || tab === "security") && (
        <Card className="p-8 text-center">
          <div className="w-16 h-16 bg-brand-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            {tab === "analytics" ? <BarChart2 size={28} className="text-brand-500" /> : <Shield size={28} className="text-brand-500" />}
          </div>
          <h3 className="font-display font-bold text-xl text-[var(--text-primary)] mb-2">
            {tab === "analytics" ? "Advanced Analytics" : "Security Center"}
          </h3>
          <p className="text-[var(--text-secondary)] max-w-sm mx-auto">Full {tab} dashboard coming in v1.1. This will include detailed reporting, audit logs, and threat monitoring.</p>
        </Card>
      )}
    </div>
  );
}
