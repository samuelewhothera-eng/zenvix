// Auth Pages - Login, Register, ForgotPassword
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Zap, ArrowRight, Mail, Lock, User, Phone, CheckCircle2 } from "lucide-react";
import { useApp } from "../context/AppContext";
import toast from "react-hot-toast";

// ===== LOGIN =====
export function LoginPage() {
  const [form, setForm] = useState({ email: "", password: "", role: "student" });
  const [showPass, setShowPass] = useState(false);
  const [errors, setErrors] = useState({});
  const { login, isLoading } = useApp();
  const navigate = useNavigate();

  const validate = () => {
    const e = {};
    if (!form.email.includes("@")) e.email = "Enter a valid email";
    if (form.password.length < 3) e.password = "Password required";
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    try {
      const user = await login(form.email, form.password, form.role);
      toast.success(`Welcome back, ${user.name.split(" ")[0]}! 🎉`);
      const path = user.role === "employer" ? "/employer" : user.role === "admin" ? "/admin" : "/dashboard";
      navigate(path);
    } catch {
      toast.error("Invalid credentials");
    }
  };

  const demoLogins = [
    { role: "student", label: "Student Demo", color: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20" },
    { role: "employer", label: "Employer Demo", color: "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20" },
    { role: "admin", label: "Admin Demo", color: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20" },
  ];

  return (
    <div className="min-h-[calc(100vh-64px)] flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-brand-600 to-purple-700 relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)", backgroundSize: "25px 25px" }} />
        <div className="relative max-w-sm text-center">
          <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center mx-auto mb-6 backdrop-blur-sm">
            <Zap size={36} className="text-white" />
          </div>
          <h2 className="font-display text-4xl font-bold text-white mb-4">Zenvix</h2>
          <p className="text-white/80 text-lg leading-relaxed mb-8">Learn. Verify. Get Hired. Your complete career platform for the digital economy.</p>
          <div className="grid grid-cols-2 gap-3 text-left">
            {["48,200+ learners", "320+ courses", "18,900+ certificates", "240+ hiring companies"].map(s => (
              <div key={s} className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2.5">
                <CheckCircle2 size={14} className="text-emerald-300 flex-shrink-0" />
                <span className="text-white text-xs font-medium">{s}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6 bg-[var(--bg-primary)]">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <Link to="/" className="flex items-center gap-2 mb-6 lg:hidden">
              <div className="w-7 h-7 bg-gradient-to-br from-brand-500 to-purple-500 rounded-lg flex items-center justify-center"><Zap size={14} className="text-white" /></div>
              <span className="font-display font-bold text-lg text-[var(--text-primary)]">Zen<span className="text-brand-500">vix</span></span>
            </Link>
            <h1 className="font-display text-3xl font-bold text-[var(--text-primary)] mb-1">Welcome back</h1>
            <p className="text-[var(--text-secondary)]">Log in to continue your learning journey</p>
          </div>

          {/* Demo login buttons */}
          <div className="mb-6">
            <p className="text-xs text-[var(--text-muted)] font-medium mb-2">Quick demo access:</p>
            <div className="flex gap-2 flex-wrap">
              {demoLogins.map(d => (
                <button
                  key={d.role}
                  onClick={() => setForm(f => ({ ...f, email: "demo@example.com", password: "demo123", role: d.role }))}
                  className={`text-xs px-3 py-1.5 rounded-lg border font-semibold transition-colors ${d.color}`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-[var(--text-primary)] mb-1.5 block">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                <input
                  type="email"
                  placeholder="amara@example.com"
                  value={form.email}
                  onChange={e => setForm(f => ({...f, email: e.target.value}))}
                  className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all ${errors.email ? "border-red-500" : "border-[var(--border-color)]"}`}
                />
              </div>
              {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-sm font-semibold text-[var(--text-primary)]">Password</label>
                <Link to="/forgot-password" className="text-xs text-brand-500 hover:text-brand-600">Forgot password?</Link>
              </div>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                <input
                  type={showPass ? "text" : "password"}
                  placeholder="••••••••"
                  value={form.password}
                  onChange={e => setForm(f => ({...f, password: e.target.value}))}
                  className={`w-full pl-10 pr-12 py-3 rounded-xl border text-sm bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all ${errors.password ? "border-red-500" : "border-[var(--border-color)]"}`}
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-[var(--text-primary)]">
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password}</p>}
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full justify-center py-3.5 text-base mt-2"
            >
              {isLoading ? (
                <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Logging in...</>
              ) : (
                <>Log In <ArrowRight size={16} /></>
              )}
            </button>
          </form>

          <p className="text-center text-sm text-[var(--text-secondary)] mt-6">
            Don't have an account?{" "}
            <Link to="/register" className="text-brand-500 hover:text-brand-600 font-semibold">Create one free</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

// ===== REGISTER =====
export function RegisterPage() {
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "student", agree: false });
  const [showPass, setShowPass] = useState(false);
  const { login, isLoading } = useApp();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.agree) { toast.error("Please accept the terms"); return; }
    await login(form.email, form.password, form.role);
    toast.success("Account created! Welcome to Zenvix 🚀");
    navigate("/dashboard");
  };

  const roles = [
    { value: "student", label: "Student / Learner", desc: "I want to learn skills and find jobs", emoji: "🎓" },
    { value: "employer", label: "Employer / Company", desc: "I want to hire verified talent", emoji: "🏢" },
  ];

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-6 bg-[var(--bg-primary)]">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <h1 className="font-display text-3xl font-bold text-[var(--text-primary)] mb-2">Create your account</h1>
          <p className="text-[var(--text-secondary)]">Join 48,200+ learners on Zenvix — free forever</p>
        </div>

        {/* Role selector */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {roles.map(r => (
            <button
              key={r.value}
              type="button"
              onClick={() => setForm(f => ({ ...f, role: r.value }))}
              className={`p-4 rounded-2xl border-2 text-left transition-all ${form.role === r.value ? "border-brand-500 bg-brand-500/5" : "border-[var(--border-color)] hover:border-brand-300"}`}
            >
              <div className="text-2xl mb-2">{r.emoji}</div>
              <p className="font-semibold text-sm text-[var(--text-primary)]">{r.label}</p>
              <p className="text-xs text-[var(--text-muted)] mt-0.5">{r.desc}</p>
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input type="text" placeholder="Full Name" value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} required
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--border-color)] text-sm bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all" />
          </div>
          <div className="relative">
            <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input type="email" placeholder="Email Address" value={form.email} onChange={e => setForm(f=>({...f,email:e.target.value}))} required
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--border-color)] text-sm bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all" />
          </div>
          <div className="relative">
            <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input type={showPass ? "text" : "password"} placeholder="Create password" value={form.password} onChange={e => setForm(f=>({...f,password:e.target.value}))} required minLength={8}
              className="w-full pl-10 pr-12 py-3 rounded-xl border border-[var(--border-color)] text-sm bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all" />
            <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]">
              {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          <label className="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" checked={form.agree} onChange={e => setForm(f=>({...f,agree:e.target.checked}))} className="mt-0.5 w-4 h-4 rounded accent-brand-500" />
            <span className="text-sm text-[var(--text-secondary)]">
              I agree to the{" "}
              <a href="#" className="text-brand-500 hover:underline">Terms of Service</a> and{" "}
              <a href="#" className="text-brand-500 hover:underline">Privacy Policy</a>
            </span>
          </label>

          <button type="submit" disabled={isLoading} className="btn-primary w-full justify-center py-3.5 text-base">
            {isLoading ? "Creating account..." : <>Create Free Account <ArrowRight size={16} /></>}
          </button>
        </form>

        <p className="text-center text-sm text-[var(--text-secondary)] mt-6">
          Already have an account?{" "}
          <Link to="/login" className="text-brand-500 font-semibold">Log in</Link>
        </p>
      </div>
    </div>
  );
}

// ===== FORGOT PASSWORD =====
export function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setSent(true);
    setLoading(false);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-6 bg-[var(--bg-primary)]">
      <div className="w-full max-w-md">
        {!sent ? (
          <>
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-brand-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Mail size={28} className="text-brand-500" />
              </div>
              <h1 className="font-display text-3xl font-bold text-[var(--text-primary)] mb-2">Reset your password</h1>
              <p className="text-[var(--text-secondary)]">Enter your email and we'll send a reset link.</p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                <input type="email" placeholder="your@email.com" value={email} onChange={e => setEmail(e.target.value)} required
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--border-color)] text-sm bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all" />
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3.5">
                {loading ? "Sending..." : "Send Reset Link"}
              </button>
            </form>
            <p className="text-center text-sm mt-4"><Link to="/login" className="text-brand-500">← Back to login</Link></p>
          </>
        ) : (
          <div className="text-center">
            <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 size={28} className="text-emerald-500" />
            </div>
            <h2 className="font-display text-2xl font-bold text-[var(--text-primary)] mb-2">Check your email</h2>
            <p className="text-[var(--text-secondary)] mb-6">We've sent a reset link to <strong>{email}</strong></p>
            <Link to="/login" className="btn-primary justify-center">Return to Login</Link>
          </div>
        )}
      </div>
    </div>
  );
}
