import { useState } from "react";
import { Edit2, Plus, Award, Briefcase, Globe, MapPin, Calendar, Save, ExternalLink } from "lucide-react";
import { mockUser, mockCertificates, mockSkillData } from "../data/mockData";
import { Card, Badge, ProgressBar, Button, Avatar } from "../components/ui";
import toast from "react-hot-toast";

const projects = [
  { id: 1, title: "E-Commerce Dashboard", desc: "React + Node.js + MongoDB full-stack app", tags: ["React", "Node.js", "MongoDB"], link: "#", image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=300&q=80" },
  { id: 2, title: "Weather App", desc: "Real-time weather using OpenWeather API", tags: ["JavaScript", "API", "CSS"], link: "#", image: "https://images.unsplash.com/photo-1504608524841-42584120d693?w=300&q=80" },
  { id: 3, title: "Portfolio Website", desc: "Personal portfolio with smooth animations", tags: ["HTML", "CSS", "JS"], link: "#", image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=300&q=80" },
];

const socialLinks = [
  { key: "github", label: "GitHub", icon: "</>", url: mockUser.socialLinks?.github },
  { key: "linkedin", label: "LinkedIn", icon: "in", url: mockUser.socialLinks?.linkedin },
  { key: "twitter", label: "Twitter/X", icon: "𝕏", url: mockUser.socialLinks?.twitter },
];

export default function ProfilePage() {
  const [editing, setEditing] = useState(false);
  const [bio, setBio] = useState(mockUser.bio);
  const [activeTab, setActiveTab] = useState("skills");

  const tabs = ["skills", "projects", "certificates", "resume"];

  const saveProfile = () => {
    setEditing(false);
    toast.success("Profile updated!");
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Profile Header */}
      <Card className="p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
          <div className="relative">
            <Avatar src={mockUser.avatar} name={mockUser.name} size="2xl" />
            <button className="absolute -bottom-1 -right-1 w-7 h-7 bg-brand-500 rounded-full flex items-center justify-center text-white shadow-sm">
              <Edit2 size={12} />
            </button>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold text-[var(--text-primary)]">{mockUser.name}</h1>
                <p className="text-[var(--text-secondary)]">{mockUser.title}</p>
                <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-[var(--text-muted)]">
                  <span className="flex items-center gap-1"><MapPin size={13} />{mockUser.location}</span>
                  <span className="flex items-center gap-1"><Calendar size={13} />Joined {mockUser.joinedDate}</span>
                </div>
              </div>
              <Button
                variant={editing ? "success" : "secondary"}
                className="flex-shrink-0"
                onClick={editing ? saveProfile : () => setEditing(true)}
              >
                {editing ? <><Save size={14} /> Save</> : <><Edit2 size={14} /> Edit Profile</>}
              </Button>
            </div>

            {editing ? (
              <textarea
                value={bio}
                onChange={e => setBio(e.target.value)}
                className="mt-3 w-full px-3 py-2.5 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/30 resize-none h-20"
              />
            ) : (
              <p className="text-sm text-[var(--text-secondary)] mt-3 leading-relaxed max-w-2xl">{bio}</p>
            )}

            {/* Social links */}
            <div className="flex items-center gap-3 mt-4">
              {socialLinks.map(({ key, label, icon, url }) => (
                <a
                  key={key}
                  href={url ? `https://${url}` : "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[var(--bg-secondary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)] transition-colors text-xs font-bold border border-[var(--border-color)]"
                >
                  <span className="text-xs">{icon}</span> {label}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-[var(--border-color)]">
          {[
            { label: "Courses Completed", value: mockUser.completedCourses },
            { label: "Certificates", value: mockUser.totalCertificates },
            { label: "Total XP", value: mockUser.xp?.toLocaleString() },
            { label: "Day Streak", value: `${mockUser.streak} 🔥` },
          ].map(s => (
            <div key={s.label} className="text-center">
              <p className="font-display font-bold text-xl text-[var(--text-primary)]">{s.value}</p>
              <p className="text-xs text-[var(--text-muted)]">{s.label}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Tabs */}
      <div className="flex gap-1 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl p-1.5">
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all capitalize ${
              activeTab === tab
                ? "bg-[var(--card-bg)] text-[var(--text-primary)] shadow-sm"
                : "text-[var(--text-muted)] hover:text-[var(--text-secondary)]"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Skills Tab */}
      {activeTab === "skills" && (
        <div className="grid sm:grid-cols-2 gap-5">
          <Card className="p-5">
            <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4">Skill Levels</h3>
            <div className="space-y-4">
              {mockSkillData.map(s => (
                <div key={s.skill}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="font-medium text-[var(--text-primary)]">{s.skill}</span>
                    <span className="font-bold" style={{ color: s.color }}>{s.level}%</span>
                  </div>
                  <div className="h-2 bg-[var(--bg-tertiary)] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${s.level}%`, backgroundColor: s.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="font-display font-bold text-base text-[var(--text-primary)] mb-4">Verified Badges</h3>
            <div className="flex flex-wrap gap-2">
              {mockUser.skills.map(skill => (
                <div key={skill} className="flex items-center gap-1.5 px-3 py-2 bg-brand-500/10 border border-brand-500/20 rounded-xl">
                  <Award size={12} className="text-brand-500" />
                  <span className="text-sm font-semibold text-brand-600 dark:text-brand-400">{skill}</span>
                </div>
              ))}
              <button
                onClick={() => toast.success("Navigate to Verify page to earn new badges!")}
                className="flex items-center gap-1.5 px-3 py-2 border-2 border-dashed border-[var(--border-color)] rounded-xl text-sm text-[var(--text-muted)] hover:border-brand-500 hover:text-brand-500 transition-colors"
              >
                <Plus size={13} /> Add Skill
              </button>
            </div>
          </Card>
        </div>
      )}

      {/* Projects Tab */}
      {activeTab === "projects" && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.map(p => (
            <Card key={p.id} hover className="overflow-hidden">
              <img src={p.image} alt={p.title} className="w-full h-36 object-cover" />
              <div className="p-4">
                <h4 className="font-display font-bold text-base text-[var(--text-primary)] mb-1">{p.title}</h4>
                <p className="text-sm text-[var(--text-secondary)] mb-3">{p.desc}</p>
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {p.tags.map(t => (
                    <span key={t} className="px-2 py-0.5 bg-[var(--bg-tertiary)] text-[var(--text-secondary)] text-xs rounded-md">{t}</span>
                  ))}
                </div>
                <a href={p.link} className="flex items-center gap-1.5 text-sm text-brand-500 hover:text-brand-600 font-semibold">
                  <Globe size={13} /> View Project
                </a>
              </div>
            </Card>
          ))}
          <Card
            className="border-dashed flex items-center justify-center min-h-48 cursor-pointer hover:border-brand-500/50 transition-colors"
            onClick={() => toast.success("Project upload coming soon!")}
          >
            <div className="text-center">
              <Plus size={24} className="text-[var(--text-muted)] mx-auto mb-2" />
              <p className="text-sm font-semibold text-[var(--text-secondary)]">Add Project</p>
            </div>
          </Card>
        </div>
      )}

      {/* Certificates Tab */}
      {activeTab === "certificates" && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {mockCertificates.map(cert => (
            <Card key={cert.id} className="p-5">
              <div className="w-10 h-10 bg-amber-400/20 rounded-2xl flex items-center justify-center mb-3">
                <Award size={20} className="text-amber-500" />
              </div>
              <h4 className="font-display font-bold text-base text-[var(--text-primary)] mb-1">{cert.title}</h4>
              <p className="text-xs text-[var(--text-muted)] mb-2">{cert.issuedDate}</p>
              <Badge variant="purple" className="mb-3">{cert.grade}</Badge>
              <p className="text-xs font-mono text-[var(--text-muted)]">{cert.verificationId}</p>
            </Card>
          ))}
        </div>
      )}

      {/* Resume Tab */}
      {activeTab === "resume" && (
        <Card className="p-8 text-center">
          <div className="w-16 h-16 bg-brand-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Briefcase size={28} className="text-brand-500" />
          </div>
          <h3 className="font-display font-bold text-xl text-[var(--text-primary)] mb-2">AI Resume Builder</h3>
          <p className="text-[var(--text-secondary)] mb-6 max-w-md mx-auto">
            We'll auto-generate a professional resume from your courses, certificates, and projects. Coming soon!
          </p>
          <Button variant="primary" onClick={() => toast.success("AI Resume builder coming in v1.1! 🚀")}>
            Generate Resume with AI
          </Button>
        </Card>
      )}
    </div>
  );
}
