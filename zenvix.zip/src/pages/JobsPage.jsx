import { useState, useEffect } from "react";
import { Search, MapPin, Clock, Users, Briefcase, ExternalLink, Bookmark, Filter, Star } from "lucide-react";
import { mockJobs, jobCategories, jobTypes } from "../data/mockData";
import { Card, Badge, Button, Modal } from "../components/ui";
import { JobCardSkeleton } from "../components/skeletons";
import toast from "react-hot-toast";

const categoryColors = {
  Frontend: "blue", Backend: "green", Design: "purple",
  Data: "orange", Marketing: "yellow", DevOps: "gray",
};
const typeColors = { "Full-time": "green", "Part-time": "blue", "Contract": "orange", "Internship": "purple" };

function JobCard({ job, onView, saved, onSave }) {
  return (
    <Card className={`p-5 transition-all duration-200 hover:shadow-card-hover hover:-translate-y-0.5 ${job.isFeatured ? "border-brand-500/30 bg-brand-500/5 dark:bg-brand-500/5" : ""}`}>
      {job.isFeatured && (
        <div className="flex items-center gap-1.5 mb-3">
          <Star size={12} className="fill-amber-400 text-amber-400" />
          <span className="text-xs font-semibold text-amber-500">Featured</span>
        </div>
      )}
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-[var(--bg-tertiary)] flex items-center justify-center flex-shrink-0 overflow-hidden border border-[var(--border-color)]">
          <img src={job.companyLogo} alt={job.company} className="w-10 h-10" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-display font-bold text-base text-[var(--text-primary)] hover:text-brand-500 transition-colors cursor-pointer" onClick={() => onView(job)}>
                {job.title}
              </h3>
              <p className="text-sm text-[var(--text-secondary)]">{job.company}</p>
            </div>
            <button onClick={() => onSave(job.id)} className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${saved ? "bg-brand-500/10 text-brand-500" : "hover:bg-[var(--bg-tertiary)] text-[var(--text-muted)]"}`}>
              <Bookmark size={15} className={saved ? "fill-current" : ""} />
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-[var(--text-secondary)]">
            <span className="flex items-center gap-1"><MapPin size={11} />{job.location}</span>
            <span className="flex items-center gap-1"><Clock size={11} />{job.posted}</span>
            <span className="flex items-center gap-1"><Users size={11} />{job.applicants} applicants</span>
          </div>

          <div className="flex flex-wrap gap-1.5 mt-3">
            <Badge variant={typeColors[job.type] || "gray"}>{job.type}</Badge>
            <Badge variant={categoryColors[job.category] || "blue"}>{job.category}</Badge>
            {job.isRemote && <Badge variant="green">🌍 Remote</Badge>}
            {job.salary && <Badge variant="orange">💰 {job.salary}</Badge>}
          </div>

          <div className="flex flex-wrap gap-1.5 mt-2">
            {job.skills.map(s => (
              <span key={s} className="px-2 py-0.5 bg-[var(--bg-tertiary)] text-[var(--text-secondary)] text-xs rounded-md">{s}</span>
            ))}
          </div>

          <div className="flex gap-2 mt-4">
            <Button variant="primary" className="text-xs py-2 px-4" onClick={() => { toast.success(`Applied to ${job.title}! 🎉`); }}>
              Quick Apply
            </Button>
            <Button variant="ghost" className="text-xs py-2 px-3" onClick={() => onView(job)}>
              View Details
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}

function JobDetailModal({ job, onClose }) {
  if (!job) return null;
  return (
    <div className="space-y-5">
      <div className="flex items-start gap-4">
        <div className="w-14 h-14 rounded-xl bg-[var(--bg-tertiary)] flex items-center justify-center border border-[var(--border-color)]">
          <img src={job.companyLogo} alt={job.company} className="w-12 h-12" />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-[var(--text-primary)]">{job.title}</h2>
          <p className="text-[var(--text-secondary)]">{job.company}</p>
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant={typeColors[job.type] || "gray"}>{job.type}</Badge>
            {job.isRemote && <Badge variant="green">🌍 Remote</Badge>}
            {job.salary && <Badge variant="orange">💰 {job.salary}</Badge>}
          </div>
        </div>
      </div>

      <div className="bg-[var(--bg-secondary)] rounded-xl p-4">
        <h4 className="font-semibold text-sm text-[var(--text-primary)] mb-2">About this role</h4>
        <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{job.description}</p>
      </div>

      <div>
        <h4 className="font-semibold text-sm text-[var(--text-primary)] mb-2">Requirements</h4>
        <ul className="space-y-2">
          {job.requirements.map(r => (
            <li key={r} className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
              <div className="w-1.5 h-1.5 bg-brand-500 rounded-full flex-shrink-0" />
              {r}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h4 className="font-semibold text-sm text-[var(--text-primary)] mb-2">Required Skills</h4>
        <div className="flex flex-wrap gap-2">
          {job.skills.map(s => (
            <span key={s} className="px-3 py-1.5 bg-brand-500/10 text-brand-600 dark:text-brand-400 text-sm rounded-lg font-medium">{s}</span>
          ))}
        </div>
      </div>

      <div className="flex gap-3 pt-2">
        <Button variant="primary" className="flex-1 justify-center py-3" onClick={() => { toast.success(`Application submitted! 🎉`); onClose(); }}>
          <Briefcase size={16} /> Apply Now
        </Button>
        <Button variant="secondary" onClick={() => toast.success("Job saved!")}>
          <Bookmark size={16} />
        </Button>
      </div>
    </div>
  );
}

export default function JobsPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [type, setType] = useState("All Types");
  const [remoteOnly, setRemoteOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const [jobs, setJobs] = useState([]);
  const [viewJob, setViewJob] = useState(null);
  const [saved, setSaved] = useState(new Set());

  useEffect(() => {
    const t = setTimeout(() => {
      let filtered = [...mockJobs];
      if (category !== "All") filtered = filtered.filter(j => j.category === category);
      if (type !== "All Types") filtered = filtered.filter(j => j.type === type);
      if (remoteOnly) filtered = filtered.filter(j => j.isRemote);
      if (search) {
        const q = search.toLowerCase();
        filtered = filtered.filter(j => j.title.toLowerCase().includes(q) || j.company.toLowerCase().includes(q) || j.skills.some(s => s.toLowerCase().includes(q)));
      }
      setJobs(filtered);
      setLoading(false);
    }, 500);
    return () => clearTimeout(t);
  }, [search, category, type, remoteOnly]);

  useEffect(() => { setLoading(true); }, [search, category, type, remoteOnly]);

  const toggleSave = (id) => {
    setSaved(s => {
      const next = new Set(s);
      if (next.has(id)) { next.delete(id); toast("Removed from saved"); }
      else { next.add(id); toast.success("Job saved!"); }
      return next;
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-3xl font-bold text-[var(--text-primary)] mb-1">Remote Job Board</h1>
        <p className="text-[var(--text-secondary)]">{mockJobs.length} open positions from top companies hiring globally</p>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search jobs, companies, skills..."
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all text-sm" />
        </div>
        <select value={type} onChange={e => setType(e.target.value)}
          className="px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] focus:outline-none text-sm cursor-pointer min-w-36">
          {jobTypes.map(t => <option key={t}>{t}</option>)}
        </select>
        <label className="flex items-center gap-2 px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] cursor-pointer text-sm font-medium text-[var(--text-secondary)] whitespace-nowrap">
          <input type="checkbox" checked={remoteOnly} onChange={e => setRemoteOnly(e.target.checked)} className="accent-brand-500" />
          Remote Only
        </label>
      </div>

      {/* Category tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {jobCategories.map(cat => (
          <button key={cat} onClick={() => setCategory(cat)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${category === cat ? "bg-brand-500 text-white" : "bg-[var(--bg-secondary)] text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] border border-[var(--border-color)]"}`}>
            {cat}
          </button>
        ))}
      </div>

      {!loading && <p className="text-sm text-[var(--text-muted)]">Showing <span className="font-bold text-[var(--text-primary)]">{jobs.length}</span> jobs</p>}

      {/* Jobs List */}
      <div className="space-y-4">
        {loading
          ? Array(4).fill(0).map((_, i) => <JobCardSkeleton key={i} />)
          : jobs.length > 0
            ? jobs.map(job => <JobCard key={job.id} job={job} onView={setViewJob} saved={saved.has(job.id)} onSave={toggleSave} />)
            : (
              <div className="text-center py-16">
                <Briefcase size={40} className="text-[var(--text-muted)] mx-auto mb-3" />
                <h3 className="font-display font-bold text-lg text-[var(--text-primary)] mb-1">No jobs found</h3>
                <p className="text-sm text-[var(--text-secondary)]">Try different filters</p>
              </div>
            )
        }
      </div>

      {/* Job Detail Modal */}
      <Modal isOpen={!!viewJob} onClose={() => setViewJob(null)} title="Job Details">
        <JobDetailModal job={viewJob} onClose={() => setViewJob(null)} />
      </Modal>
    </div>
  );
}
