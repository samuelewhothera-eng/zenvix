import { Link } from "react-router-dom";
import { Home, ArrowLeft } from "lucide-react";

export default function NotFoundPage() {
  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center text-center px-4">
      <div className="max-w-md">
        {/* Big 404 */}
        <div className="relative mb-6">
          <p className="font-display text-[160px] font-black leading-none select-none"
             style={{ color: "var(--bg-tertiary)" }}>
            404
          </p>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 bg-gradient-to-br from-brand-500 to-purple-500 rounded-3xl flex items-center justify-center shadow-glow">
              <span className="text-3xl">🔍</span>
            </div>
          </div>
        </div>

        <h1 className="font-display text-2xl font-bold text-[var(--text-primary)] mb-3">
          Page not found
        </h1>
        <p className="text-[var(--text-secondary)] mb-8 leading-relaxed">
          Looks like this page took a detour. Let's get you back on the learning path.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/" className="btn-primary justify-center">
            <Home size={16} /> Go Home
          </Link>
          <button onClick={() => window.history.back()} className="btn-secondary justify-center">
            <ArrowLeft size={16} /> Go Back
          </button>
        </div>
      </div>
    </div>
  );
}
