// hooks/useAsync.js - Generic async data fetching hook
import { useState, useEffect, useCallback } from "react";

export function useAsync(asyncFn, deps = [], immediate = true) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(immediate);
  const [error, setError] = useState(null);

  const execute = useCallback(async (...args) => {
    setLoading(true);
    setError(null);
    try {
      const result = await asyncFn(...args);
      setData(result.data);
      return result.data;
    } catch (err) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }, deps);

  useEffect(() => {
    if (immediate) execute();
  }, [execute, immediate]);

  return { data, loading, error, execute, setData };
}

// hooks/useDebounce.js
export function useDebounce(value, delay = 300) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debouncedValue;
}

// hooks/useLocalStorage.js
export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch { return initialValue; }
  });

  const setStoredValue = (newValue) => {
    try {
      setValue(newValue);
      localStorage.setItem(key, JSON.stringify(newValue));
    } catch (err) { console.error(err); }
  };

  return [value, setStoredValue];
}

// hooks/useSearch.js
import { useState } from "react";
import { useDebounce } from "./useAsync";

export function useSearch(items = [], searchKeys = ["title"]) {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, 300);

  const filtered = debouncedQuery
    ? items.filter(item =>
        searchKeys.some(key => {
          const val = item[key];
          if (Array.isArray(val)) return val.some(v => v.toLowerCase().includes(debouncedQuery.toLowerCase()));
          return typeof val === "string" && val.toLowerCase().includes(debouncedQuery.toLowerCase());
        })
      )
    : items;

  return { query, setQuery, filtered, hasResults: filtered.length > 0 };
}
