// routes/ProtectedRoute.jsx - Guards routes based on auth state and role
import { Navigate, useLocation } from "react-router-dom";
import { useApp } from "../context/AppContext";

export function ProtectedRoute({ children, allowedRoles }) {
  const { user } = useApp();
  const location = useLocation();

  if (!user) {
    // Redirect to login, preserving intended destination
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // Role mismatch - redirect to their correct dashboard
    const dash = user.role === "employer" ? "/employer"
               : user.role === "admin" ? "/admin"
               : "/dashboard";
    return <Navigate to={dash} replace />;
  }

  return children;
}

export function PublicOnlyRoute({ children }) {
  const { user } = useApp();
  if (user) {
    const dash = user.role === "employer" ? "/employer"
               : user.role === "admin" ? "/admin"
               : "/dashboard";
    return <Navigate to={dash} replace />;
  }
  return children;
}
