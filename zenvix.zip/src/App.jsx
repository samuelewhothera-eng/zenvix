import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { AppProvider } from "./context/AppContext";
import { PublicLayout, DashboardLayout, AuthLayout } from "./layouts";
import { ProtectedRoute, PublicOnlyRoute } from "./routes/ProtectedRoute";
import LandingPage from "./pages/LandingPage";
import { LoginPage, RegisterPage, ForgotPasswordPage } from "./pages/AuthPages";
import DashboardPage from "./pages/DashboardPage";
import CoursesPage from "./pages/CoursesPage";
import CoursePage from "./pages/CoursePage";
import VerifyPage from "./pages/VerifyPage";
import CertificatesPage from "./pages/CertificatesPage";
import JobsPage from "./pages/JobsPage";
import ProfilePage from "./pages/ProfilePage";
import AIAssistantPage from "./pages/AIAssistantPage";
import EmployerDashboard from "./pages/EmployerDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import NotFoundPage from "./pages/NotFoundPage";

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Routes>
          {/* ── Public marketing pages ── */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<LandingPage />} />
          </Route>

          {/* ── Auth pages (redirect to dashboard if already logged in) ── */}
          <Route element={<AuthLayout />}>
            <Route path="/login"          element={<PublicOnlyRoute><LoginPage /></PublicOnlyRoute>} />
            <Route path="/register"       element={<PublicOnlyRoute><RegisterPage /></PublicOnlyRoute>} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          </Route>

          {/* ── Student dashboard ── */}
          <Route element={<ProtectedRoute allowedRoles={["student"]}><DashboardLayout /></ProtectedRoute>}>
            <Route path="/dashboard"    element={<DashboardPage />} />
            <Route path="/courses"      element={<CoursesPage />} />
            <Route path="/courses/:id"  element={<CoursePage />} />
            <Route path="/verify"       element={<VerifyPage />} />
            <Route path="/certificates" element={<CertificatesPage />} />
            <Route path="/jobs"         element={<JobsPage />} />
            <Route path="/profile"      element={<ProfilePage />} />
            <Route path="/ai-assistant" element={<AIAssistantPage />} />
          </Route>

          {/* ── Employer dashboard ── */}
          <Route element={<ProtectedRoute allowedRoles={["employer"]}><DashboardLayout /></ProtectedRoute>}>
            <Route path="/employer" element={<EmployerDashboard />} />
          </Route>

          {/* ── Admin dashboard ── */}
          <Route element={<ProtectedRoute allowedRoles={["admin"]}><DashboardLayout /></ProtectedRoute>}>
            <Route path="/admin" element={<AdminDashboard />} />
          </Route>

          {/* ── 404 ── */}
          <Route element={<AuthLayout />}>
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </BrowserRouter>

      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: "var(--card-bg)",
            color: "var(--text-primary)",
            border: "1px solid var(--border-color)",
            borderRadius: "12px",
            fontSize: "14px",
            fontFamily: "'DM Sans', sans-serif",
            boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
          },
          success: { iconTheme: { primary: "#10b981", secondary: "#fff" } },
          error:   { iconTheme: { primary: "#ef4444", secondary: "#fff" } },
        }}
      />
    </AppProvider>
  );
}
