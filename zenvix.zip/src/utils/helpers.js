// utils/helpers.js — Shared utility functions

export const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
};

export const truncate = (str, n = 100) => (str?.length > n ? str.slice(0, n) + "…" : str);

export const slugify = (str) => str?.toLowerCase().replace(/\s+/g, "-").replace(/[^\w-]/g, "");

export const capitalize = (str) => str?.charAt(0).toUpperCase() + str?.slice(1);

export const getInitials = (name) => name?.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase() || "?";

export const formatXP = (xp) => (xp >= 1000 ? `${(xp / 1000).toFixed(1)}K` : xp.toString());

export const getLevel = (xp) => Math.floor(xp / 500) + 1;

export const getXPToNextLevel = (xp) => 500 - (xp % 500);

export const getProgressColor = (pct) => {
  if (pct >= 80) return "text-emerald-500";
  if (pct >= 50) return "text-brand-500";
  return "text-orange-500";
};

export const timeAgo = (dateStr) => {
  const seconds = Math.floor((new Date() - new Date(dateStr)) / 1000);
  if (seconds < 60) return "just now";
  const intervals = [["year", 31536000], ["month", 2592000], ["week", 604800], ["day", 86400], ["hour", 3600], ["minute", 60]];
  for (const [label, secs] of intervals) {
    const n = Math.floor(seconds / secs);
    if (n >= 1) return `${n} ${label}${n > 1 ? "s" : ""} ago`;
  }
  return "just now";
};

export const matchScore = (userSkills = [], jobSkills = []) => {
  if (!jobSkills.length) return 0;
  const matches = jobSkills.filter(s => userSkills.includes(s)).length;
  return Math.round((matches / jobSkills.length) * 100);
};

