import { Link } from "react-router-dom";
import { Zap, Globe, Code2, Code, Mail } from "lucide-react";

export default function Footer() {
  const links = {
    Platform: ["Courses", "Certifications", "Job Board", "AI Assistant", "Skill Verification"],
    Company: ["About Us", "Blog", "Careers", "Press", "Contact"],
    Support: ["Help Center", "Community", "Status", "Privacy Policy", "Terms of Service"],
    Regions: ["Nigeria", "Kenya", "Ghana", "South Africa", "Global Remote"],
  };

  const socials = [
    { href: "#", label: "Twitter/X", icon: "𝕏" },
    { href: "#", label: "GitHub", icon: "</>" },
    { href: "#", label: "LinkedIn", icon: "in" },
    { href: "#", label: "Email", icon: "@" },
  ];

  return (
    <footer className="bg-[var(--bg-secondary)] border-t border-[var(--border-color)] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-brand-500 to-purple-500 rounded-lg flex items-center justify-center">
                <Zap size={16} className="text-white" />
              </div>
              <span className="font-display font-bold text-lg text-[var(--text-primary)]">
                Zen<span className="text-brand-500">vix</span>
              </span>
            </Link>
            <p className="text-sm text-[var(--text-secondary)] leading-relaxed mb-4">
              Empowering the next generation of African tech talent with world-class education and global opportunities.
            </p>
            <div className="flex items-center gap-2">
              {socials.map(s => (
                <a key={s.label} href={s.href}
                  className="w-8 h-8 flex items-center justify-center rounded-lg bg-[var(--bg-tertiary)] text-[var(--text-muted)] hover:text-brand-500 hover:bg-brand-500/10 transition-colors text-xs font-bold">
                  {s.icon}
                </a>
              ))}
            </div>
          </div>

          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h4 className="font-display font-bold text-sm text-[var(--text-primary)] mb-4">{category}</h4>
              <ul className="space-y-2.5">
                {items.map(item => (
                  <li key={item}>
                    <a href="#" className="text-sm text-[var(--text-secondary)] hover:text-brand-500 transition-colors">{item}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-6 border-t border-[var(--border-color)] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-[var(--text-muted)]">© 2024 Zenvix. All rights reserved.</p>
          <span className="text-xs px-3 py-1.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-lg font-semibold">
            🌍 Serving 54 African countries
          </span>
        </div>
      </div>
    </footer>
  );
}
