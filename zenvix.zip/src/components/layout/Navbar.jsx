// Navbar - responsive with theme toggle and notifications
import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Menu, X, Bell, Sun, Moon, ChevronDown, Zap, LogOut, User, Settings } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { Avatar, Badge } from "../ui";
import { clsx } from "clsx";

const publicLinks = [
  { label: "How It Works", href: "/#features" },
  { label: "Courses", href: "/courses" },
  { label: "Jobs", href: "/jobs" },
  { label: "Pricing", href: "/#pricing" },
];

export default function Navbar() {
  const { user, logout, theme, toggleTheme, notifications, unreadCount, markAllRead } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const isDashboard = location.pathname.startsWith("/dashboard") ||
    location.pathname.startsWith("/employer") || location.pathname.startsWith("/admin");

  const handleLogout = () => {
    logout();
    navigate("/");
    setUserMenuOpen(false);
  };

  const dashboardPath = user?.role === "employer" ? "/employer" : user?.role === "admin" ? "/admin" : "/dashboard";

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 glass border-b border-[var(--border-color)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-gradient-to-br from-brand-500 to-purple-500 rounded-lg flex items-center justify-center shadow-sm group-hover:shadow-glow transition-all">
              <Zap size={16} className="text-white" />
            </div>
            <span className="font-display font-bold text-xl text-[var(--text-primary)]">
              Zen<span className="text-brand-500">vix</span>
            </span>
          </Link>

          {/* Desktop Nav Links */}
          {!isDashboard && (
            <div className="hidden md:flex items-center gap-1">
              {publicLinks.map(link => (
                <Link key={link.label} to={link.href} className="nav-link px-4 py-2 rounded-lg hover:bg-[var(--bg-tertiary)] text-sm">
                  {link.label}
                </Link>
              ))}
            </div>
          )}

          {/* Right side */}
          <div className="flex items-center gap-2">
            {/* Theme Toggle */}
            <button onClick={toggleTheme} className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[var(--bg-tertiary)] text-[var(--text-secondary)] transition-colors">
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {user ? (
              <>
                {/* Notifications */}
                <div className="relative">
                  <button
                    onClick={() => { setNotifOpen(!notifOpen); setUserMenuOpen(false); if (!notifOpen) markAllRead(); }}
                    className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[var(--bg-tertiary)] text-[var(--text-secondary)] transition-colors relative"
                  >
                    <Bell size={18} />
                    {unreadCount > 0 && (
                      <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-500 rounded-full" />
                    )}
                  </button>
                  {notifOpen && (
                    <div className="absolute right-0 top-12 w-80 bg-[var(--card-bg)] border border-[var(--border-color)] rounded-2xl shadow-2xl z-50 overflow-hidden animate-slide-up">
                      <div className="p-4 border-b border-[var(--border-color)]">
                        <h3 className="font-display font-bold text-sm text-[var(--text-primary)]">Notifications</h3>
                      </div>
                      <div className="divide-y divide-[var(--border-color)]">
                        {notifications.map(n => (
                          <div key={n.id} className={clsx("p-4 hover:bg-[var(--bg-secondary)] transition-colors", !n.read && "bg-brand-500/5")}>
                            <p className="text-sm text-[var(--text-primary)]">{n.text}</p>
                            <p className="text-xs text-[var(--text-muted)] mt-1">{n.time}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* User Menu */}
                <div className="relative">
                  <button
                    onClick={() => { setUserMenuOpen(!userMenuOpen); setNotifOpen(false); }}
                    className="flex items-center gap-2 px-2 py-1.5 rounded-xl hover:bg-[var(--bg-tertiary)] transition-colors"
                  >
                    <Avatar src={user.avatar} name={user.name} size="sm" />
                    <span className="hidden sm:block text-sm font-semibold text-[var(--text-primary)] max-w-24 truncate">{user.name.split(" ")[0]}</span>
                    <ChevronDown size={14} className="text-[var(--text-muted)] hidden sm:block" />
                  </button>
                  {userMenuOpen && (
                    <div className="absolute right-0 top-12 w-56 bg-[var(--card-bg)] border border-[var(--border-color)] rounded-2xl shadow-2xl z-50 overflow-hidden animate-slide-up">
                      <div className="p-4 border-b border-[var(--border-color)]">
                        <p className="font-semibold text-sm text-[var(--text-primary)]">{user.name}</p>
                        <p className="text-xs text-[var(--text-muted)]">{user.email}</p>
                      </div>
                      <div className="p-2">
                        <Link to={dashboardPath} onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)] transition-colors">
                          <User size={16} /> Dashboard
                        </Link>
                        <Link to="/profile" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)] transition-colors">
                          <Settings size={16} /> Profile
                        </Link>
                        <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors">
                          <LogOut size={16} /> Log out
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login" className="hidden sm:block btn-ghost text-sm px-4 py-2">Log in</Link>
                <Link to="/register" className="btn-primary text-sm px-4 py-2">Get Started</Link>
              </div>
            )}

            {/* Mobile menu toggle */}
            <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden w-9 h-9 flex items-center justify-center rounded-xl hover:bg-[var(--bg-tertiary)] text-[var(--text-secondary)]">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden border-t border-[var(--border-color)] bg-[var(--bg-primary)] animate-slide-up">
          <div className="px-4 py-4 space-y-1">
            {!isDashboard && publicLinks.map(link => (
              <Link key={link.label} to={link.href} className="block nav-link px-3 py-2.5 rounded-xl hover:bg-[var(--bg-tertiary)] text-sm" onClick={() => setMenuOpen(false)}>
                {link.label}
              </Link>
            ))}
            {!user && (
              <>
                <Link to="/login" className="block px-3 py-2.5 rounded-xl text-sm text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)]" onClick={() => setMenuOpen(false)}>Log in</Link>
                <Link to="/register" className="block px-3 py-2.5 rounded-xl text-sm font-semibold text-brand-500 hover:bg-brand-500/10" onClick={() => setMenuOpen(false)}>Get Started Free</Link>
              </>
            )}
          </div>
        </div>
      )}

      {/* Backdrop for dropdowns */}
      {(notifOpen || userMenuOpen) && (
        <div className="fixed inset-0 z-30" onClick={() => { setNotifOpen(false); setUserMenuOpen(false); }} />
      )}
    </nav>
  );
}
