// Sidebar - dashboard navigation
import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, BookOpen, Award, Briefcase, User, MessageSquare, BarChart2, Settings, Users, Shield, Zap, TrendingUp, CheckSquare } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { Avatar, Badge } from "../ui";
import { clsx } from "clsx";

const studentNav = [
  { label: "Dashboard", icon: LayoutDashboard, to: "/dashboard" },
  { label: "My Courses", icon: BookOpen, to: "/courses" },
  { label: "Skill Verification", icon: CheckSquare, to: "/verify" },
  { label: "Certificates", icon: Award, to: "/certificates" },
  { label: "Job Board", icon: Briefcase, to: "/jobs" },
  { label: "AI Assistant", icon: MessageSquare, to: "/ai-assistant" },
  { label: "My Profile", icon: User, to: "/profile" },
];

const employerNav = [
  { label: "Dashboard", icon: LayoutDashboard, to: "/employer" },
  { label: "Post a Job", icon: Briefcase, to: "/employer/post-job" },
  { label: "Applicants", icon: Users, to: "/employer/applicants" },
  { label: "Analytics", icon: BarChart2, to: "/employer/analytics" },
  { label: "Settings", icon: Settings, to: "/employer/settings" },
];

const adminNav = [
  { label: "Overview", icon: LayoutDashboard, to: "/admin" },
  { label: "Users", icon: Users, to: "/admin/users" },
  { label: "Courses", icon: BookOpen, to: "/admin/courses" },
  { label: "Jobs", icon: Briefcase, to: "/admin/jobs" },
  { label: "Analytics", icon: TrendingUp, to: "/admin/analytics" },
  { label: "Security", icon: Shield, to: "/admin/security" },
  { label: "Settings", icon: Settings, to: "/admin/settings" },
];

export default function Sidebar({ isMobileOpen, onClose }) {
  const { user } = useApp();
  const location = useLocation();
  
  const navItems = user?.role === "employer" ? employerNav
    : user?.role === "admin" ? adminNav
    : studentNav;

  const roleBadge = user?.role === "employer" ? { label: "Employer", variant: "purple" }
    : user?.role === "admin" ? { label: "Admin", variant: "red" }
    : { label: `Level ${user?.level || 1}`, variant: "blue" };

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={onClose} />
      )}

      {/* Sidebar */}
      <aside className={clsx(
        "fixed top-0 left-0 h-full w-64 bg-[var(--sidebar-bg)] border-r border-[var(--border-color)] z-40 flex flex-col transition-transform duration-300",
        "pt-16", // account for navbar
        isMobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* User Profile Summary */}
        <div className="p-4 border-b border-[var(--border-color)]">
          <Link to="/profile" className="flex items-center gap-3 p-2 rounded-xl hover:bg-[var(--bg-tertiary)] transition-colors">
            <Avatar src={user?.avatar} name={user?.name} size="md" />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-[var(--text-primary)] truncate">{user?.name}</p>
              <Badge variant={roleBadge.variant} className="mt-0.5 text-xs">{roleBadge.label}</Badge>
            </div>
          </Link>
          {user?.role === "student" && (
            <div className="mt-3 px-2">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[var(--text-muted)]">XP Progress</span>
                <span className="font-semibold text-brand-500">{user?.xp?.toLocaleString()} XP</span>
              </div>
              <div className="h-1.5 bg-[var(--bg-tertiary)] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-brand-500 to-purple-500 rounded-full" style={{ width: "68%" }} />
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 overflow-y-auto">
          <div className="space-y-1">
            {navItems.map(item => {
              const isActive = location.pathname === item.to ||
                (item.to !== "/" && location.pathname.startsWith(item.to + "/"));
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={onClose}
                  className={isActive ? "sidebar-item-active" : "sidebar-item"}
                >
                  <item.icon size={18} />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </nav>

        {/* Bottom Brand */}
        <div className="p-4 border-t border-[var(--border-color)]">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-gradient-to-br from-brand-500 to-purple-500 rounded-lg flex items-center justify-center">
              <Zap size={13} className="text-white" />
            </div>
            <div>
              <p className="font-display font-bold text-sm text-[var(--text-primary)]">Zenvix</p>
              <p className="text-xs text-[var(--text-muted)]">v1.0.0 MVP</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
