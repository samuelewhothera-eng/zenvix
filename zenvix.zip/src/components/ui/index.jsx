// components/ui/index.jsx
// Reusable atomic UI components for Zenvix
import { clsx } from "clsx";
import { Loader2, Star, CheckCircle2 } from "lucide-react";

// ===== BUTTON =====
export function Button({ children, variant = "primary", size = "md", loading, disabled, className, onClick, type = "button" }) {
  const base = "inline-flex items-center justify-center gap-2 font-semibold rounded-xl transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100";
  const variants = {
    primary: "bg-brand-500 hover:bg-brand-600 text-white shadow-sm hover:shadow-glow",
    secondary: "bg-transparent border border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)]",
    ghost: "bg-transparent text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)]",
    danger: "bg-red-500 hover:bg-red-600 text-white",
    success: "bg-emerald-500 hover:bg-emerald-600 text-white",
    outline: "border-2 border-brand-500 text-brand-500 hover:bg-brand-500 hover:text-white",
  };
  const sizes = {
    sm: "text-xs px-3 py-1.5",
    md: "text-sm px-5 py-2.5",
    lg: "text-base px-6 py-3",
    xl: "text-lg px-8 py-4",
  };
  return (
    <button
      type={type}
      className={clsx(base, variants[variant], sizes[size], className)}
      disabled={disabled || loading}
      onClick={onClick}
    >
      {loading && <Loader2 className="animate-spin" size={16} />}
      {children}
    </button>
  );
}

// ===== BADGE =====
export function Badge({ children, variant = "blue", className }) {
  const variants = {
    blue: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
    green: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    purple: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
    orange: "bg-orange-500/10 text-orange-600",
    red: "bg-red-500/10 text-red-600",
    gray: "bg-gray-500/10 text-gray-600 dark:text-gray-400",
    yellow: "bg-yellow-500/10 text-yellow-600",
  };
  return (
    <span className={clsx("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold", variants[variant], className)}>
      {children}
    </span>
  );
}

// ===== CARD =====
export function Card({ children, className, hover, onClick }) {
  return (
    <div
      className={clsx(
        "bg-[var(--card-bg)] border border-[var(--border-color)] rounded-2xl shadow-card transition-all duration-200",
        hover && "hover:shadow-card-hover hover:-translate-y-0.5 cursor-pointer",
        className
      )}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

// ===== INPUT =====
export function Input({ label, error, hint, icon: Icon, className, ...props }) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-semibold text-[var(--text-primary)]">{label}</label>}
      <div className="relative">
        {Icon && (
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]">
            <Icon size={16} />
          </div>
        )}
        <input
          className={clsx(
            "w-full px-4 py-3 rounded-xl border bg-[var(--bg-secondary)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all duration-200 text-sm",
            Icon && "pl-10",
            error ? "border-red-500 focus:ring-red-500/20" : "border-[var(--border-color)]",
            className
          )}
          {...props}
        />
      </div>
      {error && <p className="text-xs text-red-500">{error}</p>}
      {hint && !error && <p className="text-xs text-[var(--text-muted)]">{hint}</p>}
    </div>
  );
}

// ===== PROGRESS BAR =====
export function ProgressBar({ value, max = 100, showLabel, color = "brand", className }) {
  const pct = Math.min(100, (value / max) * 100);
  const colors = {
    brand: "from-brand-500 to-brand-400",
    purple: "from-purple-500 to-purple-400",
    green: "from-emerald-500 to-emerald-400",
    orange: "from-orange-500 to-orange-400",
  };
  return (
    <div className={clsx("flex items-center gap-3", className)}>
      <div className="flex-1 h-2 bg-[var(--bg-tertiary)] rounded-full overflow-hidden">
        <div
          className={clsx("h-full bg-gradient-to-r rounded-full transition-all duration-700", colors[color])}
          style={{ width: `${pct}%` }}
        />
      </div>
      {showLabel && <span className="text-xs font-semibold text-[var(--text-secondary)] w-8 text-right">{Math.round(pct)}%</span>}
    </div>
  );
}

// ===== AVATAR =====
export function Avatar({ src, name, size = "md", className }) {
  const sizes = { xs: "w-6 h-6 text-xs", sm: "w-8 h-8 text-sm", md: "w-10 h-10 text-base", lg: "w-12 h-12 text-lg", xl: "w-16 h-16 text-xl", "2xl": "w-20 h-20 text-2xl" };
  const initials = name?.split(" ").map(n => n[0]).slice(0, 2).join("") || "?";
  return src ? (
    <img src={src} alt={name} className={clsx("rounded-full object-cover flex-shrink-0", sizes[size], className)} />
  ) : (
    <div className={clsx("rounded-full bg-brand-500 text-white flex items-center justify-center font-bold flex-shrink-0", sizes[size], className)}>
      {initials}
    </div>
  );
}

// ===== STAR RATING =====
export function StarRating({ rating, reviews }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map(i => (
        <Star key={i} size={14} className={i <= Math.round(rating) ? "fill-amber-400 text-amber-400" : "text-gray-300 dark:text-gray-600"} />
      ))}
      <span className="text-xs font-semibold text-amber-500 ml-1">{rating}</span>
      {reviews && <span className="text-xs text-[var(--text-muted)]">({reviews.toLocaleString()})</span>}
    </div>
  );
}

// ===== EMPTY STATE =====
export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="w-16 h-16 bg-[var(--bg-tertiary)] rounded-2xl flex items-center justify-center mb-4">
        {Icon && <Icon size={28} className="text-[var(--text-muted)]" />}
      </div>
      <h3 className="font-display font-bold text-lg text-[var(--text-primary)] mb-2">{title}</h3>
      {description && <p className="text-sm text-[var(--text-secondary)] mb-6 max-w-xs">{description}</p>}
      {action}
    </div>
  );
}

// ===== STAT CARD =====
export function StatCard({ label, value, change, icon: Icon, color = "blue" }) {
  const colors = {
    blue: "bg-blue-500/10 text-blue-500",
    green: "bg-emerald-500/10 text-emerald-500",
    purple: "bg-purple-500/10 text-purple-500",
    orange: "bg-orange-500/10 text-orange-500",
  };
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-[var(--text-secondary)] font-medium mb-1">{label}</p>
          <p className="font-display text-2xl font-bold text-[var(--text-primary)]">{value}</p>
          {change && (
            <p className={clsx("text-xs font-semibold mt-1", change > 0 ? "text-emerald-500" : "text-red-500")}>
              {change > 0 ? "+" : ""}{change}% from last month
            </p>
          )}
        </div>
        {Icon && (
          <div className={clsx("w-10 h-10 rounded-xl flex items-center justify-center", colors[color])}>
            <Icon size={20} />
          </div>
        )}
      </div>
    </Card>
  );
}

// ===== SELECT =====
export function Select({ label, options, className, ...props }) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-semibold text-[var(--text-primary)]">{label}</label>}
      <select
        className={clsx(
          "w-full px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-secondary)] text-[var(--text-primary)] focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all duration-200 text-sm cursor-pointer",
          className
        )}
        {...props}
      >
        {options.map(opt => (
          <option key={typeof opt === "string" ? opt : opt.value} value={typeof opt === "string" ? opt : opt.value}>
            {typeof opt === "string" ? opt : opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}

// ===== MODAL =====
export function Modal({ isOpen, onClose, title, children, size = "md" }) {
  if (!isOpen) return null;
  const sizes = { sm: "max-w-sm", md: "max-w-lg", lg: "max-w-2xl", xl: "max-w-4xl" };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div
        className={clsx("relative w-full bg-[var(--card-bg)] rounded-3xl shadow-2xl border border-[var(--border-color)] animate-slide-up", sizes[size])}
        onClick={e => e.stopPropagation()}
      >
        {title && (
          <div className="flex items-center justify-between p-6 border-b border-[var(--border-color)]">
            <h2 className="font-display font-bold text-xl text-[var(--text-primary)]">{title}</h2>
            <button onClick={onClose} className="btn-ghost p-2 rounded-lg">✕</button>
          </div>
        )}
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

// ===== CHECK ITEM =====
export function CheckItem({ text }) {
  return (
    <div className="flex items-center gap-2.5 text-sm text-[var(--text-secondary)]">
      <CheckCircle2 size={16} className="text-emerald-500 flex-shrink-0" />
      <span>{text}</span>
    </div>
  );
}

// ===== TOOLTIP =====
export function Tooltip({ content, children }) {
  return (
    <div className="relative group inline-flex">
      {children}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 text-xs rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-150 pointer-events-none z-50">
        {content}
      </div>
    </div>
  );
}
