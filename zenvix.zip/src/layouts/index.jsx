// layouts/index.jsx - Page layout wrappers
import { useState } from "react";
import { Outlet } from "react-router-dom";
import { Menu } from "lucide-react";
import Navbar from "../components/layout/Navbar";
import Sidebar from "../components/layout/Sidebar";
import Footer from "../components/layout/Footer";

// Public pages (landing, auth, etc.)
export function PublicLayout() {
  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      <Navbar />
      <main className="pt-16">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

// Dashboard pages (student, employer, admin)
export function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[var(--bg-secondary)]">
      <Navbar />
      <Sidebar isMobileOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      {/* Main Content */}
      <div className="lg:ml-64 pt-16">
        {/* Mobile sidebar trigger */}
        <div className="lg:hidden fixed bottom-4 left-4 z-30">
          <button
            onClick={() => setSidebarOpen(true)}
            className="w-12 h-12 bg-brand-500 text-white rounded-2xl flex items-center justify-center shadow-glow"
          >
            <Menu size={20} />
          </button>
        </div>

        <main className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

// Minimal layout (auth pages)
export function AuthLayout() {
  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      <Navbar />
      <main className="pt-16">
        <Outlet />
      </main>
    </div>
  );
}
