# Zenvix — Future-of-Work Platform (Frontend MVP)

A full-featured React frontend for Zenvix: a platform that helps students learn
digital skills, earn verified certificates, and land remote jobs globally.

---

## Quick Start (3 commands)

```bash
npm install
npm run dev
```

Open → http://localhost:5173

---

## Demo Logins

On the Login page, click any **Quick Demo** button, then click **Log In**.

| Role     | Dashboard          | What you see                          |
|----------|--------------------|---------------------------------------|
| Student  | /dashboard         | Full learning dashboard, courses, jobs |
| Employer | /employer          | Job posting, applicants, analytics    |
| Admin    | /admin             | Platform stats, user management       |

---

## Pages Built (12 total)

| Page                  | Route            | Description                          |
|-----------------------|------------------|--------------------------------------|
| Landing               | /                | Hero, features, testimonials, CTA    |
| Login                 | /login           | Auth with demo quick-login           |
| Register              | /register        | Role selector (student / employer)   |
| Forgot Password       | /forgot-password | Email reset flow                     |
| Student Dashboard     | /dashboard       | XP chart, progress, interviews       |
| Courses               | /courses         | Search, filter, enroll               |
| Single Course         | /courses/:id     | Video player, lessons, notes         |
| Skill Verification    | /verify          | Timed quiz with score modal          |
| Certificates          | /certificates    | Beautiful cert viewer + download     |
| Job Board             | /jobs            | Search, filter, apply, save          |
| Profile               | /profile         | Skills, projects, certs, resume      |
| AI Assistant          | /ai-assistant    | Full chat UI + career cards          |
| Employer Dashboard    | /employer        | Post jobs, view applicants           |
| Admin Dashboard       | /admin           | Analytics, users, courses            |
| 404                   | *                | Friendly not-found page              |

---

## Tech Stack

| Layer         | Technology                    |
|---------------|-------------------------------|
| Framework     | React 18 + Vite               |
| Routing       | React Router DOM v6           |
| Styling       | Tailwind CSS v3               |
| State         | React Context API             |
| Charts        | Recharts                      |
| Icons         | Lucide React                  |
| Notifications | React Hot Toast               |
| HTTP (ready)  | Axios (wired, mock active)    |
| Fonts         | Google Fonts (Syne + DM Sans) |

---

## Folder Structure

```
zenvix/
├── public/
│   └── vite.svg
├── src/
│   ├── assets/              # Static images
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.jsx   # Top nav, theme toggle, notifications
│   │   │   ├── Sidebar.jsx  # Dashboard sidebar (role-aware)
│   │   │   └── Footer.jsx   # Public footer
│   │   ├── ui/
│   │   │   └── index.jsx    # Button, Card, Badge, Input, Modal, etc.
│   │   └── skeletons/
│   │       └── index.jsx    # Loading skeleton components
│   ├── context/
│   │   └── AppContext.jsx   # Auth state + theme toggle
│   ├── data/
│   │   └── mockData.js      # All realistic mock data
│   ├── hooks/
│   │   └── useAsync.js      # useAsync, useDebounce, useSearch
│   ├── layouts/
│   │   └── index.jsx        # PublicLayout, DashboardLayout, AuthLayout
│   ├── pages/
│   │   ├── LandingPage.jsx
│   │   ├── AuthPages.jsx    # Login, Register, ForgotPassword
│   │   ├── DashboardPage.jsx
│   │   ├── CoursesPage.jsx
│   │   ├── CoursePage.jsx
│   │   ├── VerifyPage.jsx
│   │   ├── CertificatesPage.jsx
│   │   ├── JobsPage.jsx
│   │   ├── ProfilePage.jsx
│   │   ├── AIAssistantPage.jsx
│   │   ├── EmployerDashboard.jsx
│   │   ├── AdminDashboard.jsx
│   │   └── NotFoundPage.jsx
│   ├── routes/
│   │   └── ProtectedRoute.jsx  # Auth + role guards
│   ├── services/
│   │   └── api.js           # Axios instance + all service functions
│   ├── utils/
│   │   └── helpers.js       # formatDate, truncate, matchScore, etc.
│   ├── App.jsx              # Root router
│   ├── main.jsx             # React entry point
│   └── index.css            # Global styles + Tailwind layers
├── tailwind.config.js
├── postcss.config.js
├── vite.config.js
├── package.json
└── README.md
```

---

## Connecting to a Real Backend

All API calls live in `src/services/api.js`.

Every function currently returns mock data after a simulated delay.
To connect your Node.js + Express backend:

1. Create `.env` in the project root:
   ```
   VITE_API_URL=http://localhost:5000/api
   ```

2. In `src/services/api.js`, replace mock returns with real axios calls:
   ```js
   // Before (mock):
   await delay(500);
   return { data: mockCourses, error: null };

   // After (real):
   const res = await api.get("/courses");
   return { data: res.data, error: null };
   ```

JWT tokens are automatically attached via the axios interceptor already set up.

---

## Features Checklist

- [x] Dark / Light mode (persisted to localStorage)
- [x] Fully responsive (mobile, tablet, desktop)
- [x] Role-based route protection (student / employer / admin)
- [x] Loading skeleton states
- [x] Toast notification system
- [x] Search + filter on courses and jobs
- [x] Timed quiz engine with score modal
- [x] Beautiful certificate viewer
- [x] Interactive AI chat interface
- [x] Charts and analytics (Recharts)
- [x] Modals, dropdowns, tab systems
- [x] Persistent theme + auth via localStorage
- [x] API service layer (ready for backend swap)

---

## Environment Variables

Create `.env` in the root directory:

```env
VITE_API_URL=http://localhost:5000/api
```

---

## Scripts

```bash
npm run dev      # Start dev server → http://localhost:5173
npm run build    # Production build → dist/
npm run preview  # Preview production build
```

---

## Next Steps (Backend)

1. **Node.js + Express** REST API
2. **MongoDB** with Mongoose models: User, Course, Job, Certificate, Assessment
3. **JWT authentication** (already wired in axios interceptor)
4. **Cloudinary** for image/video uploads
5. **Stripe** for Pro subscriptions
6. **OpenAI API** to power the AI Assistant

Built with ❤️ for African tech talent.
